"""
Matplotlib backend for Basthon's isolated kernel.

This is matplotlib's WebAgg backend (backend_webagg_core) where the
websocket between Python (the "server") and mpl.js (the browser client)
is replaced by the MessagePort of a kernel iframe:

 + Python runs in the kernel (worker), renders the figure with Agg and
   sends PNG frames and JSON events to the iframe ;
 + mpl.js runs in the kernel iframe (see src/iframe/), displays the figure,
   the toolbar, the coordinates... and sends back user interactions.

Only the transport and the figure download are Basthon specific.
"""

import base64
import functools
import json
from io import BytesIO
from pathlib import Path

import js  # type: ignore
from pyodide.ffi import create_proxy, to_js  # type: ignore

import matplotlib
from matplotlib import interactive, is_interactive
from matplotlib._pylab_helpers import Gcf
from matplotlib.backend_bases import _Backend
from matplotlib.backends import backend_webagg_core as core

from basthon import kernel

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["FigureCanvasBasthon", "FigureManagerBasthon"]


_root = Path(__file__).parent

# Pyodide's matplotlib wheel does not ship the static files of WebAgg
# (web_backend/), restore them (copy of matplotlib's ones, see README).
_web_backend = Path(core.__file__).parent / "web_backend"
if not _web_backend.exists():
    if matplotlib.__version__ != "3.5.2":
        raise ImportError(
            f"WebAgg static files are not provided for matplotlib "
            f"{matplotlib.__version__} (only for 3.5.2)."
        )
    _web_backend.symlink_to(_root / "web_backend")

# figures are updated as soon as they change (as matplotlib_pyodide does)
interactive(True)


class KernelIFrameSocket:
    """
    The websocket of WebAgg replaced by the MessagePort of a kernel
    iframe (see FigureManagerWebAgg.add_web_socket).
    """

    def __init__(self, manager):
        """
        Display a kernel iframe and listen to its messages.

        :param manager: the figure's manager.
        """
        self.manager = manager
        self._port = js.basthon.displayKernelIFrame(_iframe_html())
        self._on_message_proxy = create_proxy(self._on_message)
        self._port.onmessage = self._on_message_proxy

    def send_json(self, content):
        """
        Send a JSON message to the iframe.

        :param content: the message (JSON serializable).
        """
        self._port.postMessage(json.dumps(content))

    def send_binary(self, blob):
        """
        Send a frame (PNG) to the iframe.

        :param blob: the frame's bytes.
        """
        data = to_js(blob)
        self._port.postMessage(data, to_js([data.buffer]))

    def close(self):
        """Stop listening to the iframe and close the port."""
        self._port.onmessage = None
        self._port.close()
        self._on_message_proxy.destroy()

    def _on_message(self, event):
        """
        Handle a message of the iframe: a new client, a download request or an
        event for the figure's manager.

        :param event: the port's message event (JSON data).
        """
        message = json.loads(event.data)
        e_type = message.get("type")
        if e_type == "supports_binary":
            # always supported by MessagePort, but it is the first message of
            # a new client (e.g. the reloaded page of the basthon command):
            # as a new websocket (see add_web_socket), its device pixel ratio
            # is 1 until it sends its own, and it needs the figure size
            canvas = self.manager.canvas
            canvas._set_device_pixel_ratio(1)
            self.manager.resize(*canvas.figure.bbox.size)
            return
        if e_type == "basthon_download":
            self._download(message.get("format"))
            return
        self.manager.handle_json(message)

    def _download(self, format):
        """
        Download the figure (save button of the toolbar).

        :param format: the file format (e.g. ``"png"``), ignored if not
            supported.
        """
        canvas = self.manager.canvas
        if format not in canvas.get_supported_filetypes():
            return
        with BytesIO() as buffer:
            canvas.figure.savefig(buffer, format=format)
            kernel.download(f"plot.{format}", buffer.getvalue())


@functools.cache
def _iframe_html():
    """
    The kernel iframe page: our bundle with matplotlib's client
    (mpl.js, style and toolbar images).
    """
    page = (_root / "bundle" / "iframe.html").read_text()
    script = FigureManagerBasthon.get_javascript()
    static = Path(FigureManagerBasthon.get_static_file_path())
    style = (static / "css" / "mpl.css").read_text()
    images = {}
    images_path = Path(matplotlib.get_data_path()) / "images"
    for _, _, image, _ in FigureManagerBasthon.ToolbarCls.toolitems:
        if image is None:
            continue
        for name in (f"{image}.png", f"{image}_large.png"):
            path = images_path / name
            if path.exists():
                data = base64.b64encode(path.read_bytes()).decode()
                images[f"_images/{name}"] = f"data:image/png;base64,{data}"
    # download formats (see FigureCanvasBasthon.filetypes)
    extensions = [
        ext[0]
        for _, ext in sorted(
            FigureCanvasBasthon.get_supported_filetypes_grouped().items()
        )
    ]
    script += f"\nmpl.extensions = {json.dumps(extensions)};\n"
    script += f"window.basthonMplImages = {json.dumps(images)};\n"
    assert "</script" not in script.lower()
    head = f"<style>{style}</style><script>{script}</script>"
    return page.replace("</head>", f"{head}</head>", 1)


class FigureCanvasBasthon(core.FigureCanvasWebAggCore):
    """WebAgg's canvas, without the pgf format (it needs LaTeX)."""

    # pgf needs LaTeX
    filetypes = {
        k: v for k, v in core.FigureCanvasWebAggCore.filetypes.items() if k != "pgf"
    }

    def __init__(self, *args, **kwargs):
        """
        :param ``*args``: ``FigureCanvasWebAggCore``'s arguments.
        :param ``**kwargs``: ``FigureCanvasWebAggCore``'s keyword arguments.
        """
        self._drawing = False
        super().__init__(*args, **kwargs)

    def draw(self):
        """Draw the figure (``draw_idle`` is ignored meanwhile)."""
        self._drawing = True
        try:
            super().draw()
        finally:
            self._drawing = False

    def draw_idle(self):
        """
        Request a drawing, unless the figure is being drawn: drawing makes
        artists stale that call ``draw_idle`` (interactive mode), such requests
        would make the clients draw again and again.
        """
        # drawing makes artists stale that call draw_idle (interactive
        # mode): such requests would make the clients draw again and again
        if not self._drawing:
            super().draw_idle()


# toolbar tooltips (shown in the status message): in French, clear for
# students and short enough to stay on one line with the default figure size
_TOOLTIPS = {
    "Home": "Revenir à la vue d'origine",
    "Back": "Vue précédente",
    "Forward": "Vue suivante",
    "Pan": "Glisser pour déplacer, clic droit pour zoomer",
    "Zoom": "Tracer un rectangle pour zoomer",
    "Download": "Télécharger au format choisi",
}


class NavigationToolbarBasthon(core.NavigationToolbar2WebAgg):
    """WebAgg's toolbar, with French tooltips."""

    toolitems = [
        (name, _TOOLTIPS.get(name, tooltip), image, method)
        for name, tooltip, image, method in core.NavigationToolbar2WebAgg.toolitems
    ]


class FigureManagerBasthon(core.FigureManagerWebAgg):
    """WebAgg's figure manager, its clients being kernel iframes."""

    ToolbarCls = NavigationToolbarBasthon

    def show(self):
        """Display the figure in a new kernel iframe."""
        self.add_web_socket(KernelIFrameSocket(self))

    def destroy(self):
        """Displayed figures stop interacting (last frame remains)."""
        for socket in list(self.web_sockets):
            self.remove_web_socket(socket)
            socket.close()


@_Backend.export
class _BackendBasthon(_Backend):
    """The ``module://matplotlib_basthon_backend`` backend."""

    FigureCanvas = FigureCanvasBasthon
    FigureManager = FigureManagerBasthon

    @staticmethod
    def draw_if_interactive():
        """Request a drawing of the active figure in interactive mode."""
        manager = Gcf.get_active()
        if manager is not None and is_interactive():
            manager.canvas.draw_idle()

    @staticmethod
    def show(*args, **kwargs):
        """
        Display the current figure (as matplotlib_pyodide does).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        manager = Gcf.get_active()
        if manager is not None:
            manager.show()
