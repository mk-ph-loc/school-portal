import basthon
from pathlib import Path
from binascii import b2a_base64
import importlib.util
import mimetypes
import sys

__all__ = [
    "display",
    "display_pretty",
    "display_html",
    "display_markdown",
    "display_svg",
    "display_png",
    "display_jpeg",
    "display_latex",
    "display_json",
    "display_javascript",
    "display_pdf",
    "clear_output",
    "Image",
    "display_image",
    "HTML",
    "IFrame",
    "SVG",
    "Markdown",
    "Latex",
    "Audio",
    "Code",
]


display = basthon.display


def clear_output(wait=False):
    """
    Clear the output of the running notebook cell (the console ignores it).

    :param wait: if ``True``, the output is cleared only when new output is
        displayed, which avoids flickering.
    """
    basthon.clear_output(wait)


def _display_mimetype(mimetype, objs, raw=False, metadata=None):
    """
    Display objects with one MIME type (implementation of the
    ``display_*`` functions).

    :param mimetype: the MIME type (e.g. ``"image/png"``).
    :param objs: the objects to display, or raw data if ``raw`` is ``True``.
    :param raw: whether the objects are raw data of this MIME type rather
        than Python objects with a representation.
    :param metadata: ignored.
    """
    if metadata:
        metadata = {mimetype: metadata}
    if raw:
        # turn list of pngdata into list of { 'image/png': pngdata }
        objs = [{mimetype: obj} for obj in objs]
    display(*objs, raw=raw, metadata=metadata, include=[mimetype])


# -----------------------------------------------------------------------------
# Main functions
# -----------------------------------------------------------------------------


def display_pretty(*objs, **kwargs):
    """
    Display the pretty (default) representation of objects (``text/plain``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("text/plain", objs, **kwargs)


def display_html(*objs, **kwargs):
    """
    Display the HTML representation of objects (``text/html``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("text/html", objs, **kwargs)


def display_markdown(*objs, **kwargs):
    """
    Display the Markdown representation of objects (``text/markdown``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """

    _display_mimetype("text/markdown", objs, **kwargs)


def display_svg(*objs, **kwargs):
    """
    Display the SVG representation of objects (``image/svg+xml``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("image/svg+xml", objs, **kwargs)


def display_png(*objs, **kwargs):
    """
    Display the PNG representation of objects (``image/png``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("image/png", objs, **kwargs)


def display_jpeg(*objs, **kwargs):
    """
    Display the JPEG representation of objects (``image/jpeg``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("image/jpeg", objs, **kwargs)


def display_latex(*objs, **kwargs):
    """
    Display the LaTeX representation of objects (``text/latex``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("text/latex", objs, **kwargs)


def display_json(*objs, **kwargs):
    """
    Display the JSON representation of objects (``application/json``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("application/json", objs, **kwargs)


def display_javascript(*objs, **kwargs):
    """
    Display the JavaScript representation of objects (``application/javascript``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("application/javascript", objs, **kwargs)


def display_pdf(*objs, **kwargs):
    """
    Display the PDF representation of objects (``application/pdf``).

    :param ``*objs``: the objects to display, or raw data if ``raw`` is
        ``True``.
    :param ``**kwargs``: ``raw`` (whether the objects are raw data rather
        than Python objects with a representation), ``metadata`` (ignored).
    """
    _display_mimetype("application/pdf", objs, **kwargs)


class Image:
    """A PNG image from its bytes."""

    def __init__(self, data, format="png"):
        """
        :param data: the image's bytes.
        :param format: the image's format (``"png"`` only).
        :raises ValueError: for another format.
        """
        if format.lower() != "png":
            raise ValueError("Only PNG format is supported.")
        self.format = format
        self.data = data

    def _repr_png_(self):
        """:return: the image in base64."""
        return b2a_base64(self.data).decode("ascii")


def display_image(img):
    """
    Display an image from an array (e.g. a NumPy array, in grayscale if it
    has a single channel).

    :param img: the image's array.
    """
    from matplotlib import image
    import base64
    import io

    def _repr_png_():
        """:return: the image in base64."""
        raw = io.BytesIO()
        image.imsave(raw, img, format="png", cmap="gray")
        raw.seek(0)
        return base64.b64encode(raw.read()).decode()

    dummy = type("image", (), {})()
    dummy._repr_png_ = _repr_png_
    display(dummy)


class TextDisplayObject:
    """Base class for SVG, HTML, Markdown, Latex..."""

    def __init__(self, data=None, filename=None):
        """
        :param data: the text.
        :param filename: the file to read the text from, if ``data`` is
            ``None``.
        :raises TypeError: if the data is not a string.
        """
        if data is None:
            data = Path(filename).read_text()
        self.data = data
        if self.data is not None and not isinstance(self.data, str):
            raise TypeError(
                "%s expects text, not %r" % (self.__class__.__name__, self.data)
            )


class HTML(TextDisplayObject):
    """HTML to display."""

    def _repr_html_(self):
        """:return: the HTML."""
        return self.data


class SVG(TextDisplayObject):
    """SVG to display."""

    def _repr_svg_(self):
        """:return: the SVG."""
        return self.data


class Latex(TextDisplayObject):
    """LaTeX to display."""

    def _repr_latex_(self):
        """:return: the LaTeX."""
        return self.data


class Markdown(TextDisplayObject):
    """Markdown to display."""

    def _repr_markdown_(self):
        """:return: the Markdown."""
        return self.data


class IFrame(HTML):
    """An iframe to display."""

    def __init__(self, src, width, height):
        """
        :param src: the iframe's URL.
        :param width: its width.
        :param height: its height.
        """
        super().__init__(
            f'<iframe src="{src}" allowfullscreen="" width="{width}" height="{height}" frameborder="0"></iframe>'
        )


class Code(TextDisplayObject):
    """
    Source code, syntax-highlighted by Pygments in HTML and LaTeX. Pygments
    is only loaded if the code imports it (``import pygments``), the code
    being shown as text otherwise (with a warning on stderr).
    """

    def __init__(self, data=None, url=None, filename=None, language=None):
        """
        :param data: the code.
        :param url: a URL to fetch the code from (the server must allow it:
            CORS).
        :param filename: a file to read the code from.
        :param language: the short name of a Pygments lexer, guessed from the
            file name or the code if not given.
        """
        if data is None and url is not None:
            from pyodide.http import open_url

            data = open_url(url).read()
        self.language = language
        self.filename = filename
        super().__init__(data=data, filename=filename)
        # Basthon loads the packages imported by the user's code only
        if importlib.util.find_spec("pygments") is None:
            print(
                "Code: add 'import pygments' to your program to highlight the code.",
                file=sys.stderr,
            )

    def _get_lexer(self):
        """:return: the Pygments lexer."""
        if self.language:
            from pygments.lexers import get_lexer_by_name

            return get_lexer_by_name(self.language)
        elif self.filename:
            from pygments.lexers import get_lexer_for_filename

            return get_lexer_for_filename(self.filename)
        else:
            from pygments.lexers import guess_lexer

            return guess_lexer(self.data)

    def __repr__(self):
        return self.data

    def _repr_html_(self):
        """:return: the highlighted code in HTML."""
        from pygments import highlight
        from pygments.formatters import HtmlFormatter

        fmt = HtmlFormatter()
        style = "<style>{}</style>".format(fmt.get_style_defs(".output_html"))
        return style + highlight(self.data, self._get_lexer(), fmt)

    def _repr_latex_(self):
        """:return: the highlighted code in LaTeX."""
        from pygments import highlight
        from pygments.formatters import LatexFormatter

        return highlight(self.data, self._get_lexer(), LatexFormatter())


# ogg is not recognized, fix this
mimetypes.add_type("application/ogg", ".ogg")


class Audio:
    """
    An audio player (only in the notebook).

    Examples:

    >>> import numpy as np
    >>> framerate = 44100
    >>> t = np.linspace(0, 5, framerate * 5)
    >>> data = np.sin(2 * np.pi * 220 * t) + np.sin(2 * np.pi * 224 * t)
    >>> Audio(data, rate=framerate)

    Stereo (or more channels):

    >>> Audio([np.sin(2 * np.pi * 220 * t), np.sin(2 * np.pi * 224 * t)], rate=framerate)

    From a URL:

    >>> Audio(url="https://example.org/sound.ogg")
    """

    _read_flags = "rb"

    def __init__(
        self,
        data=None,
        filename=None,
        url=None,
        embed=None,
        rate=None,
        autoplay=False,
        normalize=True,
        *,
        element_id=None,
    ):
        """
        :param data: the sound: a 1D (mono) or 2D (one waveform per channel)
            NumPy array, a list of samples (mono), or the bytes of a WAV file.
        :param filename: the path of an audio file: only its type is guessed
            from its name, the file is not read (give its bytes as ``data``).
        :param url: the URL of an audio file.
        :param embed: whether the data is embedded in the page (``True`` unless
            ``url`` is given).
        :param rate: the sampling rate, required for arrays and lists.
        :param autoplay: whether the sound starts playing at once.
        :param normalize: whether samples are rescaled to the maximum range;
            otherwise they must be between -1 and 1.
        :param element_id: the id of the ``audio`` element, if any.
        """
        if filename is None and url is None and data is None:
            raise ValueError("No audio data found. Expecting filename, url, or data.")
        if embed is False and url is None:
            raise ValueError("No url found. Expecting url when embed=False")

        if url is not None and embed is not True:
            self.embed = False
        else:
            self.embed = True
        self.autoplay = autoplay
        self.element_id = element_id
        self.url = url
        self.filename = filename
        self.data = data
        self.reload()

        if self.data is not None and not isinstance(self.data, bytes):
            if rate is None:
                raise ValueError(
                    "rate must be specified when data is a numpy array or list of audio samples."
                )
            self.data = Audio._make_wav(data, rate, normalize)

    def reload(self):
        """Guess the audio's MIME type from its file name or URL (WAV by default)."""
        import mimetypes

        if self.embed:
            pass  # super(Audio, self).reload()

        if self.filename is not None:
            self.mimetype = mimetypes.guess_type(self.filename)[0]
        elif self.url is not None:
            self.mimetype = mimetypes.guess_type(self.url)[0]
        else:
            self.mimetype = "audio/wav"

    @staticmethod
    def _make_wav(data, rate, normalize):
        """
        Make a WAV file of samples (16 bits).

        :param data: the samples (an array or a list).
        :param rate: the sampling rate.
        :param normalize: whether the samples are rescaled to the maximum range.
        :return: the file's bytes.
        """
        from io import BytesIO

        # bypass audioop
        try:
            import wave
        except ImportError:
            # fix audioop not present in pyodide
            from types import ModuleType

            m = ModuleType("audioop")
            import sys

            sys.modules[m.__name__] = m
            m.__file__ = m.__name__ + ".py"
            import wave

        try:
            scaled, nchan = Audio._validate_and_normalize_with_numpy(data, normalize)
        except ImportError:
            scaled, nchan = Audio._validate_and_normalize_without_numpy(data, normalize)

        fp = BytesIO()
        waveobj = wave.open(fp, mode="wb")
        waveobj.setnchannels(nchan)
        waveobj.setframerate(rate)
        waveobj.setsampwidth(2)
        waveobj.setcomptype("NONE", "NONE")
        waveobj.writeframes(scaled)
        val = fp.getvalue()
        waveobj.close()

        return val

    @staticmethod
    def _validate_and_normalize_with_numpy(data, normalize):
        """
        Convert samples to 16 bits PCM with NumPy (channels interleaved).

        :param data: the samples.
        :param normalize: whether the samples are rescaled to the maximum range.
        :return: the PCM bytes and the number of channels.
        """
        import numpy as np

        data = np.array(data, dtype=float)
        if len(data.shape) == 1:
            nchan = 1
        elif len(data.shape) == 2:
            # In wave files,channels are interleaved. E.g.,
            # "L1R1L2R2..." for stereo. See
            # http://msdn.microsoft.com/en-us/library/windows/hardware/dn653308(v=vs.85).aspx
            # for channel ordering
            nchan = data.shape[0]
            data = data.T.ravel()
        else:
            raise ValueError("Array audio input must be a 1D or 2D array")

        max_abs_value = np.max(np.abs(data))
        normalization_factor = Audio._get_normalization_factor(max_abs_value, normalize)
        scaled = data / normalization_factor * 32767
        return scaled.astype("<h").tobytes(), nchan

    @staticmethod
    def _validate_and_normalize_without_numpy(data, normalize):
        """
        Convert mono samples to 16 bits PCM without NumPy.

        :param data: the samples.
        :param normalize: whether the samples are rescaled to the maximum range.
        :return: the PCM bytes and the number of channels (1).
        """
        import array
        import sys

        data = array.array("f", data)

        try:
            max_abs_value = float(max([abs(x) for x in data]))
        except TypeError as e:
            raise TypeError(
                "Only lists of mono audio are " "supported if numpy is not installed"
            ) from e

        normalization_factor = Audio._get_normalization_factor(max_abs_value, normalize)
        scaled = array.array("h", [int(x / normalization_factor * 32767) for x in data])
        if sys.byteorder == "big":
            scaled.byteswap()
        nchan = 1
        return scaled.tobytes(), nchan

    @staticmethod
    def _get_normalization_factor(max_abs_value, normalize):
        """
        Factor dividing the samples.

        :param max_abs_value: the samples' maximum absolute value.
        :param normalize: whether the samples are rescaled to the maximum range.
        :return: the factor.
        :raises ValueError: if a sample is out of [-1, 1] without
            normalization.
        """
        if not normalize and max_abs_value > 1:
            raise ValueError(
                "Audio data must be between -1 and 1 when normalize=False."
            )
        return max_abs_value if normalize else 1

    def _data_and_metadata(self):
        """shortcut for returning metadata with url information, if defined"""
        md = {}
        if self.url:
            md["url"] = self.url
        if md:
            return self.data, md
        else:
            return self.data

    def _repr_html_(self):
        """:return: the HTML ``audio`` element."""
        src = """
                <audio {element_id} controls="controls" {autoplay}>
                    <source src="{src}" type="{type}" />
                    Your browser does not support the audio element.
                </audio>
              """
        return src.format(
            src=self.src_attr(),
            type=self.mimetype,
            autoplay=self.autoplay_attr(),
            element_id=self.element_id_attr(),
        )

    def src_attr(self):
        """
        :return: the audio's source: a data URL of the data if embedded, the
            URL otherwise.
        """
        import base64

        if self.embed and (self.data is not None):
            data = base64 = base64.b64encode(self.data).decode("ascii")
            return """data:{type};base64,{base64}""".format(
                type=self.mimetype, base64=data
            )
        elif self.url is not None:
            return self.url
        else:
            return ""

    def autoplay_attr(self):
        """:return: the ``autoplay`` attribute, if any."""
        if self.autoplay:
            return 'autoplay="autoplay"'
        else:
            return ""

    def element_id_attr(self):
        """:return: the ``id`` attribute, if any."""
        if self.element_id:
            return 'id="{element_id}"'.format(element_id=self.element_id)
        else:
            return ""
