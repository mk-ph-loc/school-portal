class RequestException(IOError):
    """There was an ambiguous exception that occurred while handling your
    request.
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize RequestException with `request` and `response` objects.

        :param ``*args``: the exception's arguments.
        :param ``**kwargs``: ``request`` and ``response``, and the exception's
            keyword arguments.
        """
        response = kwargs.pop("response", None)
        self.response = response
        self.request = kwargs.pop("request", None)
        if response is not None and not self.request and hasattr(response, "request"):
            self.request = self.response.request
        super().__init__(*args, **kwargs)


class ConnectionError(RequestException):
    """A Connection error occurred."""
