# rcviz : a small recursion call graph vizualization decorator
# Copyright (c) Ran Dugal 2014
# Licensed under the GPLv2, which is available at
# http://www.gnu.org/licenses/gpl-2.0.html
# Rewriten for Basthon by Romain Casati and licenced under the same license

import inspect
import logging
import copy
import os
import graphviz as gviz

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def trim_stack(stack):
    """
    Remove the frames above the user's code (the console's or the notebook's)
    from a stack.

    :param stack: the stack (``inspect.stack()``).
    :return: the trimmed stack.
    """
    for i in range(len(stack) - 1, -1, -1):
        if os.path.basename(stack[i].filename).startswith("<basthon-input-"):
            break
    return stack[: i + 1]


class CallGraph(object):
    """
    The calls of a decorated function (nodes) and who called whom (edges),
    drawn with Graphviz.
    """

    def __init__(self):
        """Create an empty graph."""
        self._callers = {}  # caller_fn_id : NodeData
        self._counter = 1  # track call order
        self._unwindcounter = 1  # track unwind order
        self._frames = []  # keep frame objects reference

    def get_callers(self):
        """:return: the calls (``NodeData``) by frame id."""
        return self._callers

    def get_counter(self):
        """:return: the number of the next call."""
        return self._counter

    def get_unwindcounter(self):
        """:return: the number of the next return."""
        return self._unwindcounter

    def increment(self):
        """Count a call."""
        self._counter += 1

    def increment_unwind(self):
        """Count a return."""
        self._unwindcounter += 1

    def get_frames(self):
        """
        :return: the frames of the calls (kept alive so that their ids stay
            unique).
        """
        return self._frames

    def callgraph(self, show_null_returns=True):
        """
        Draw the graph: a node per call (arguments, tracked data and returned
        value), an edge per call labelled with its order and its return's one.

        :param show_null_returns: whether a returned ``None`` is shown.
        :return: the Graphviz graph.
        """
        g = gviz.Digraph()
        g.graph_attr["label"] = "nodes=%s" % len(self._callers)
        g.graph_attr["fontname"] = "helvetica"
        g.node_attr["fontname"] = "helvetica"
        g.edge_attr["fontname"] = "helvetica"

        # create nodes
        for frame_id, node in self._callers.items():

            auxstr = ""
            for param, val in node.auxdata.items():
                auxstr += " | %s: %s" % (param, val)

            if not show_null_returns and node.ret is None:
                label = "{ %s(%s) %s }" % (node.fn_name, node.argstr(), auxstr)
            else:
                label = "{ %s(%s) %s | ret: %s }" % (
                    node.fn_name,
                    node.argstr(),
                    auxstr,
                    node.ret,
                )
            g.node(
                str(frame_id),
                shape="Mrecord",
                label=label,
                fontsize=str(13),
                labelfontsize=str(13),
            )

        # edge colors
        step = 200 // self._counter
        cur_color = 0

        # create edges
        for frame_id, node in self._callers.items():
            child_nodes = []
            for child_id, counter, unwind_counter in node.child_methods:
                child_nodes.append(child_id)
                cur_color = step * counter
                color = "#%2x%2x%2x" % (cur_color, cur_color, cur_color)
                label = "%s (&uArr;%s)" % (counter, unwind_counter)
                g.edge(
                    str(frame_id),
                    str(child_id),
                    label=label,
                    fontcolor="#999999",
                    color=str(color),
                    fontsize=str(8),
                    labelfontsize=str(8),
                )

            # order edges l to r
            # FIXME: This code doesn't seem to do anything
            # It causes the Graphviz dot command to issue
            # compilation errors (it affects Jupyter's display due to the
            # non-zero return value).
            """if len(child_nodes) > 1:
                sg = gviz.Digraph(name="foo")
                sg.graph_attr['rank'] = 'same'
                prev_node = None
                for child_node in child_nodes:
                    if prev_node:
                        sg.edge(str(prev_node), str(child_node),
                                color="#ffffff")
                    prev_node = child_node
                g.subgraph(sg)"""

        return g

    def _repr_svg_(self):
        """:return: the SVG of the graph."""
        return self.callgraph._repr_svg_()


class NodeData(object):
    """A call of the decorated function."""

    def __init__(
        self, _args=None, _kwargs=None, _fnname="", _ret=None, _childmethods=[]
    ):
        """
        :param _args: the call's arguments.
        :param _kwargs: the call's keyword arguments.
        :param _fnname: the function's name.
        :param _ret: the returned value.
        :param _childmethods: the calls it made: [frame id, call order, return
            order].
        """
        self.args = _args
        self.kwargs = _kwargs
        self.fn_name = _fnname
        self.ret = _ret
        self.child_methods = _childmethods  # [ (method, gcounter) ]

        self.auxdata = {}  # user assigned track data

    def __str__(self):
        return "%s -> child_methods: %s" % (self.nodestr(), self.child_methods)

    def nodestr(self):
        """:return: the call as ``ret = f(args)``."""
        return "%s = %s(%s)" % (self.ret, self.fn_name, self.argstr())

    def argstr(self):
        """:return: the call's arguments as text."""
        s_args = ",".join([str(arg) for arg in self.args])
        s_kwargs = ",".join([(str(k), str(v)) for (k, v) in self.kwargs.items()])
        return "%s%s" % (s_args, s_kwargs)


def viz(f, *args, **kwargs):
    """
    Decorator recording the calls of a (recursive) function. The decorated
    function has a ``callgraph()`` method drawing the graph of its last
    call (a new call starts a new graph) and a ``track(**data)`` method
    adding data to the node of the running call.

    :param f: the function.
    :param ``*args``: ignored.
    :param ``**kwargs``: ignored.
    :return: the decorated function.
    """
    _callgraph = None
    _callcount = 0  # incremented and decremented at each call

    def track(**kwargs):
        """
        Add data to the node of the running call (shown in the graph).

        :param ``**kwargs``: the data by name.
        """
        fullstack = trim_stack(inspect.stack())
        call_frame_id = id(fullstack[2][0])
        g_callers = callgraph.get_callers()
        node = g_callers.get(call_frame_id)
        if node:
            node.auxdata.update(copy.deepcopy(kwargs))

    def callgraph(*args, **kwargs):
        """
        Draw the graph of the last call.

        :param ``*args``: passed to ``CallGraph.callgraph``.
        :param ``**kwargs``: passed to ``CallGraph.callgraph``
            (``show_null_returns``).
        :return: the Graphviz graph, ``None`` if the function was not called.
        """
        nonlocal _callgraph

        if _callgraph is not None:
            return _callgraph.callgraph(*args, **kwargs)

    def wrapped_f(*args, **kwargs):
        """
        The decorated function: call ``f`` and record the call.

        :param ``*args``: ``f``'s arguments.
        :param ``**kwargs``: ``f``'s keyword arguments.
        :return: ``f``'s result.
        """
        nonlocal _callgraph, _callcount

        if _callcount == 0:
            _callgraph = CallGraph()

        _callcount += 1

        # Expected parameters for the function being wrapped
        g_callers = _callgraph.get_callers()
        g_frames = _callgraph.get_frames()

        # find the caller frame, and add self as a child node
        caller_frame_id = None

        fullstack = trim_stack(inspect.stack())

        if len(fullstack) > 2:
            caller_frame_id = id(fullstack[2][0])

        this_frame_id = id(fullstack[0][0])

        if this_frame_id not in g_frames:
            g_frames.append(fullstack[0][0])

        if this_frame_id not in g_callers.keys():
            g_callers[this_frame_id] = NodeData(args, kwargs, f.__name__, None, [])

        edgeinfo = None
        if caller_frame_id:
            edgeinfo = [this_frame_id, _callgraph.get_counter()]
            g_callers[caller_frame_id].child_methods.append(edgeinfo)
            _callgraph.increment()

        ret = f(*args, **kwargs)
        g_callers[this_frame_id].ret = copy.deepcopy(ret)

        if edgeinfo:
            edgeinfo.append(_callgraph.get_unwindcounter())
            _callgraph.increment_unwind()

        _callcount -= 1

        return ret

    wrapped_f.track = track
    wrapped_f.callgraph = callgraph
    return wrapped_f
