from importlib.resources import files as _files
import js
from pyodide.ffi import to_js as _to_js

# loading proj4js
with (_files("proj4py") / "proj4.min.js").open() as f:
    jscode = f.read()

js.eval(jscode)

# WGS84 in latitude/longitude order (the usual one), instead of
# proj4js' longitude/latitude
_WGS84 = (
    "+title=WGS 84 (long/lat) +proj=longlat +ellps=WGS84 +datum=WGS84"
    " +units=degrees +axis=neu"
)
js.proj4.defs("EPSG:4326", _WGS84)
js.proj4.defs("WGS84", _WGS84)


def _is_coord(x):
    """
    Whether an argument is coordinates (a list, tuple or dict).

    :param x: the argument.
    """
    return isinstance(x, (list, tuple, dict))


def _js(x):
    """
    Convert an argument to JS (dicts as JS objects, e.g. coordinates
    ``{"x": ..., "y": ...}``).

    :param x: the argument.
    :return: the JS value.
    """
    return _to_js(x, dict_converter=js.Object.fromEntries)


def wrap(func):
    """
    Wrap a proj4js function to call it with Python arguments.

    :param func: the JS function.
    :return: the wrapped function.
    """

    def f(*args):
        """
        :param ``*args``: the function's arguments.
        :return: the function's result.
        """
        return func(*(_js(x) for x in args))

    return f


def _py(result, coords):
    """
    Convert a result of proj4js to Python, of the coordinates' type (list,
    tuple or dict).

    :param result: the JS result.
    :param coords: the given coordinates.
    :return: the Python result.
    """
    result = result.to_py()
    return tuple(result) if isinstance(coords, tuple) else result


class Converter:
    """Transformation between two projections, proj4js' converter
    with Python coordinates."""

    def __init__(self, converter):
        """:param converter: the proj4js converter."""
        self._converter = converter

    def __getattr__(self, name):
        return getattr(self._converter, name)

    # the projections' axes (e.g. our WGS84's) are only taken into
    # account by proj4js with enforceAxis
    def forward(self, coords, enforce_axis=True):
        """
        Transform coordinates from the source projection to the destination one.

        :param coords: the coordinates (list, tuple or dict).
        :param enforce_axis: whether the projections' axes (e.g. latitude first
            for WGS84) are taken into account.
        :return: the transformed coordinates, of the same type.
        """
        return _py(self._converter.forward(_js(coords), enforce_axis), coords)

    def inverse(self, coords, enforce_axis=True):
        """
        Transform coordinates from the destination projection to the source one.

        :param coords: the coordinates (list, tuple or dict).
        :param enforce_axis: whether the projections' axes (e.g. latitude first
            for WGS84) are taken into account.
        :return: the transformed coordinates, of the same type.
        """
        return _py(self._converter.inverse(_js(coords), enforce_axis), coords)


# internal proj4 points to main JS proj4
def proj4(*args):
    """
    The ``proj4`` function of proj4js: ``proj4(dest)`` or
    ``proj4(source, dest)`` returns a converter, ``proj4(dest, coords)`` or
    ``proj4(source, dest, coords)`` transforms coordinates. The source
    projection is WGS84 (latitude, longitude) by default.

    :param ``*args``: the projections (names, e.g. ``"EPSG:2154"``, or
        definitions), then the coordinates, if any.
    :return: a converter, or the transformed coordinates.
    """
    # source projection defaults to proj4js' internal WGS84 (computed
    # before our lat/lon definition): make it explicit
    if len(args) == 1 or (len(args) == 2 and _is_coord(args[1])):
        args = ("EPSG:4326",) + args
    *projs, coords = args if len(args) == 3 else (*args, None)
    converter = Converter(js.proj4(*(_js(x) for x in projs)))
    # direct transformation of coordinates
    return converter if coords is None else converter.forward(coords)


proj4.defs = wrap(js.proj4.defs)

# Lambert 93 definition
proj4.defs(
    "EPSG:2154",
    "+proj=lcc +lat_1=49 +lat_2=44 +lat_0=46.5 +lon_0=3 +x_0=700000 +y_0=6600000 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs",
)
