# This file is from PythonTutor, modified for Basthon's purpose.

from . import pg_logger
import json


def finalizer(input_code, output_trace):
    """
    Final form of a trace.

    :param input_code: the traced code.
    :param output_trace: its trace.
    :return: the dict expected by PythonTutor's visualizer.
    """
    return dict(code=input_code, trace=output_trace)


def generate_trace(
    code,
    cumulative=False,
    heapPrimitives=False,
    allmodules=False,
    input=False,
    probe_exprs=None,
):
    """
    Generate the trace of code for PythonTutor's visualizer (pytutor.js).

    :param code: the user's code.
    :param cumulative: output a cumulative trace.
    :param heapPrimitives: render primitives as heap objects.
    :param allmodules: allow importing all the installed Python modules.
    :param input: JSON list of strings for the simulated ``input``.
    :param probe_exprs: JSON list of expressions whose values to probe at
        each step (advanced).
    :return: the trace.
    """

    if probe_exprs:
        probe_exprs = json.loads(probe_exprs)

    return pg_logger.exec_script_str_local(
        code,
        input,
        cumulative,
        heapPrimitives,
        finalizer,
        probe_exprs=probe_exprs,
        allow_all_modules=bool(allmodules),
    )
