# viz.js (Graphviz compiled to Wasm) can only be instantiated
# asynchronously: it is done by Basthon's kernel once this package
# is loaded, before running the code importing it (see the
# "basthon.setup" entry point in pyproject.toml).

from importlib.resources import files as _files
import js


async def setup():
    """Load viz.js and instantiate it as ``js.basthonViz`` (once)."""
    if hasattr(js, "basthonViz"):
        return
    with (_files("graphviz") / "viz-global.js").open() as f:
        # defines Viz
        js.eval(f.read())
    js.basthonViz = await js.Viz.instance()
