"""Basthon: run Graphviz with viz.js (Graphviz compiled to Wasm)
instead of a ``dot`` subprocess (there is none in the browser)."""

import os
import pathlib
import subprocess
import typing

import js
from basthon import download
from pyodide.ffi import to_js

from . import execute

__all__ = ["run_check", "render", "version"]


def _get_viz():
    """Return the viz.js instance created by Basthon's kernel (see _setup.py)."""
    return js.basthonViz


def _parse_command(cmd: typing.Sequence[typing.Union[os.PathLike, str]]):
    """
    Engine and format of a ``dot_command.command()`` argument list
    (renderers and formatters are ignored by viz.js).

    :param cmd: the ``dot`` command's arguments.
    :return: (engine, format), ``None`` for those not given.
    """
    engine = format_ = None
    for arg in map(str, cmd):
        if arg.startswith("-K"):
            engine = arg[2:]
        elif arg.startswith("-T"):
            format_ = arg[2:].partition(":")[0]
    return engine, format_


def _is_font_noise(error) -> bool:
    """
    Whether a viz.js error is the warning about a non-ASCII character's
    width: viz.js has no font files, so it estimates the text widths and
    warns (once) for any accented letter, which the browser renders fine.
    """
    return "no value for width of non-ASCII character" in error.message


def _format_error(error) -> str:
    """A viz.js error as ``dot`` writes it on stderr (viz.js' warnings
    already start with ``Warning: ``)."""
    prefix = f"{error.level.capitalize()}: "
    message = error.message
    if not message.startswith(prefix):
        message = prefix + message
    return f"{message}\n"


def run_check(
    cmd: typing.Sequence[typing.Union[os.PathLike, str]],
    *,
    input: typing.Union[bytes, str, None] = None,
    input_lines: typing.Optional[execute.BytesOrStrIterator] = None,
    encoding: typing.Optional[str] = None,
    quiet: bool = False,
    **kwargs,
) -> subprocess.CompletedProcess:
    """
    Same as ``execute.run_check()`` for a ``dot`` command reading its stdin,
    but run with viz.js (SVG output only).

    :param cmd: the ``dot`` command's arguments.
    :param input: the DOT source.
    :param input_lines: the DOT source's lines, instead of ``input``.
    :param encoding: the encoding of the input and outputs, bytes if
        ``None``.
    :param quiet: if ``True``, viz.js' warnings are not printed on stderr.
    :param ``**kwargs``: ignored (``subprocess.run``'s arguments).
    :return: the completed "process" (its stdout being the SVG).
    :raises ValueError: if the output format is not SVG.
    :raises CalledProcessError: if viz.js fails to render.
    """
    engine, format_ = _parse_command(cmd)
    if format_ != "svg":
        raise ValueError(
            f"unsupported format: {format_!r}"
            " (only 'svg' is supported by Graphviz in Basthon)"
        )

    if input_lines is not None:
        input = list(input_lines)
        input = (b"" if input and isinstance(input[0], bytes) else "").join(input)
    if isinstance(input, bytes):
        input = input.decode(encoding or "utf-8")

    options = to_js(
        {"engine": engine, "format": format_}, dict_converter=js.Object.fromEntries
    )
    result = _get_viz().render(input or "", options)
    stderr = "".join(
        _format_error(error) for error in result.errors if not _is_font_noise(error)
    )
    returncode = 0 if result.status == "success" else 1
    stdout = result.output if returncode == 0 else None
    if encoding is None:
        stderr = stderr.encode()
        if stdout is not None:
            stdout = stdout.encode()

    if not quiet and stderr:
        execute._write_stderr(stderr)

    if returncode:
        raise execute.CalledProcessError(returncode, cmd, output=stdout, stderr=stderr)

    return subprocess.CompletedProcess(cmd, returncode, stdout=stdout, stderr=stderr)


def render(
    cmd: typing.Sequence[typing.Union[os.PathLike, str]],
    filepath: pathlib.Path,
    outfile: pathlib.Path,
    *,
    quiet: bool = False,
    scale: float = 1,
) -> None:
    """
    Render a DOT source file with viz.js and download the result as
    ``outfile.name`` (SVG, or PNG converted from SVG) instead of writing
    ``outfile``.

    :param cmd: the ``dot`` command's arguments.
    :param filepath: the DOT source file.
    :param outfile: the output file (only its name is used).
    :param quiet: if ``True``, viz.js' warnings are not printed on stderr.
    :param scale: the scale of a PNG image.
    :raises ValueError: if the format is neither SVG nor PNG.
    """
    _, format_ = _parse_command(cmd)
    if format_ not in ("svg", "png"):
        raise ValueError(
            f"unsupported format: {format_!r}"
            " (only 'svg' and 'png' are supported by Graphviz in Basthon)"
        )

    svg_cmd = ["-Tsvg" if str(arg).startswith("-T") else arg for arg in cmd]
    svg = run_check(svg_cmd, input=filepath.read_bytes(), quiet=quiet).stdout

    if format_ == "svg":
        download(outfile.name, svg)
    else:
        download_png_from_svg(svg, outfile.name, scale)


def download_png_from_svg(svg: bytes, filename: str, scale: float) -> None:
    """
    Download a PNG image converted from an SVG one by the main thread
    (the kernel's worker can't decode SVG images).

    :param svg: the SVG (encoded).
    :param filename: the downloaded file's name.
    :param scale: the scale of the image.
    """
    js.basthon.downloadSVGAsPNG(svg.decode(), filename, scale)


def version() -> typing.Tuple[int, ...]:
    """Return the Graphviz version number tuple of viz.js (loaded by _setup.py)."""
    return tuple(int(d) for d in js.Viz.graphvizVersion.split("."))
