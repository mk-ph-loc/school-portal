"""
A p5.js instance mode wrapper running on top of Pyodide for Basthon.

Basic usage:

x, y = 100, 50

def setup(sketch):
    sketch.createCanvas(400, 200)

def draw(sketch):
    sketch.background(0)
    sketch.fill(255)
    sketch.rect(x, y, 50, 50)

sketch = p5.instance.run(setup, draw)
p5.instance.stop(sketch)  # equivalent to sketch.stop()
"""

from . import _core  # /!\ do not remove! this ensure p5.js is loaded
from . import _events

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["run", "stop", "delete", "load_library"]

# p5.sound classes (SoundFile, Oscillator, ...)
__all__ += _core.sound_classes
globals().update({c: _core.SoundClass(c) for c in _core.sound_classes})


def __dir__():
    return __all__


class P5SketchInstance(_core.P5SketchBase):
    """
    P5 instance object derived from core P5SketchBase, see _core.py.
    """

    def _wrap(self, sketch, entry_points):
        """
        Wrap the user's functions so that they take the sketch as first
        argument.

        :param sketch: the p5.js instance.
        :param entry_points: the user's functions by entry point name.
        :return: the wrapped functions by entry point name.
        """
        return {
            name: _events.wrap(f, prefix=(sketch,)) for name, f in entry_points.items()
        }


def run(setup, draw=None, preload=None, **handlers):
    """
    Run an existing sketch using ``run(sketch)`` or create and run a new one
    using ``run(setup, draw)`` where ``setup`` and ``draw`` are functions
    taking a p5 sketch as first argument.

    Event handlers are passed as keyword arguments, they take the sketch
    as first argument and optionally the event as second one
    (e.g. ``run(setup, draw, mousePressed=on_click)``).

    :param setup: the function called once at the start, or a sketch to
        resume.
    :param draw: the function called at each frame.
    :param preload: the function called before ``setup`` (e.g. to load
        files), if any.
    :param ``**handlers``: the event handlers by name.
    :return: the sketch.
    """
    if draw is None and isinstance(setup, P5SketchInstance):
        return setup.run()

    return P5SketchInstance(setup, draw, preload, handlers).run()


def stop(sketch):
    """
    Stop a sketch (no more calls to draw nor to the event handlers).

    :param sketch: the sketch returned by ``run``.
    """
    return sketch.stop()


def delete(sketch):
    """
    Delete a sketch and its canvas.

    :param sketch: the sketch returned by ``run``.
    """
    return sketch.delete()


def load_library(url):
    """
    Load a JavaScript library (e.g. a p5.js add-on) with its URL.

    :param url: the library's URL.
    :return: a promise resolved once the library is loaded.
    """
    return _core.load_library(url)
