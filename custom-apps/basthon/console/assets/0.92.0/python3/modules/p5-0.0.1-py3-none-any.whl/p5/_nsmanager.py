"""
A scope/namespace manager for managing tricky 'from p5 import *'.
"""

from basthon import kernel

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["NSManager"]


def __dir__():
    """Names exported by the module."""
    return __all__


class NSManager(object):
    """
    A namespace manager for tracking p5.js global impot (import *).
    Basic usage is:
      (1) create object before p5 import *
      (2) call to update_attributes after import
    """

    def __init__(self, attributes):
        """
        Remember the names of the namespace before ``from p5 import *``.

        :param attributes: the names of the p5.js attributes.
        """
        self._initial_ns = set(kernel.locals().keys())
        self._attributes = attributes.copy()
        self._tracked_attributes = None

    def _init_tracked_attributes(self, namespace):
        """
        Track the p5.js attributes added to the namespace since the manager's
        creation (by ``from p5 import *``).

        :param namespace: the namespace.
        """
        namespace = set(namespace.keys())
        self._tracked_attributes = (namespace - self._initial_ns) & self._attributes

    def update_attributes(self, from_object, namespace=None):
        """
        Copy the tracked attributes of an object to a namespace.

        :param from_object: the object (the p5.js instance).
        :param namespace: the namespace, the user's global one by default.
        """
        if self._tracked_attributes is None:
            self._init_tracked_attributes(namespace)
        if namespace is None:
            namespace = kernel.locals()
        for a in self._tracked_attributes:
            namespace[a] = getattr(from_object, a)

    def get_from_global_ns(self, name):
        """
        Get a variable of the user's global namespace.

        :param name: the variable's name.
        :return: its value, ``None`` if undefined.
        """
        return kernel.locals().get(name)
