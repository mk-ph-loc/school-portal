"""
User-defined p5.js entry points: preload, setup, draw and event handlers.

Binding is transport agnostic: Python callables are attached to the
p5.js instance and p5.js dispatches events itself, calling them back.
In legacy mode, p5.js listens to the real DOM. In isolated mode, the
same binding will be used, events being relayed to the p5.js instance
(running in the worker) from a kernel iframe.
"""

import inspect

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = [
    "LIFECYCLE",
    "EVENT_HANDLERS",
    "ENTRY_POINTS",
    "check_names",
    "wrap",
    "attach",
    "detach",
]


def __dir__():
    return __all__


# called without argument by p5.js
LIFECYCLE = ("preload", "setup", "draw")

# called with the DOM event as only argument by p5.js
# (see `entryPoints` in p5.js)
EVENT_HANDLERS = (
    "deviceMoved",
    "deviceTurned",
    "deviceShaken",
    "doubleClicked",
    "mousePressed",
    "mouseReleased",
    "mouseMoved",
    "mouseDragged",
    "mouseClicked",
    "mouseWheel",
    "touchStarted",
    "touchMoved",
    "touchEnded",
    "keyPressed",
    "keyReleased",
    "keyTyped",
    "windowResized",
)

ENTRY_POINTS = LIFECYCLE + EVENT_HANDLERS


def check_names(names):
    """
    Raise TypeError on unknown entry point names.

    :param names: the names of the entry points.
    """
    for name in names:
        if name not in ENTRY_POINTS:
            raise TypeError(f"P5: unknown entry point '{name}'.")


def _max_positional(func):
    """
    Max number of positional arguments accepted by a function.

    :param func: the function.
    :return: the number of arguments, ``None`` if unlimited or unknown.
    """
    try:
        signature = inspect.signature(func)
    except (TypeError, ValueError):
        return None
    count = 0
    for p in signature.parameters.values():
        if p.kind == p.VAR_POSITIONAL:
            return None
        if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD):
            count += 1
    return count


def wrap(func, before=None, prefix=()):
    """
    Wrap a user function to be called back by p5.js. The arguments sent by
    p5.js (the DOM event for handlers) are passed only if the function
    accepts them, so ``def mousePressed():`` and ``def mousePressed(event):``
    are both valid. The return value is forwarded to p5.js (returning
    ``False`` prevents the browser's default behavior).

    :param func: the user's function.
    :param before: called before each call to ``func`` (e.g. to update
        global variables like ``mouseX``), if any.
    :param prefix: arguments passed first (e.g. the sketch in instance
        mode).
    :return: the wrapped function.
    """
    max_args = _max_positional(func)

    def wrapper(*args):
        if before is not None:
            before()
        args = prefix + args
        if max_args is not None:
            args = args[:max_args]
        return func(*args)

    return wrapper


def attach(sketch, entry_points):
    """
    Attach (wrapped) entry points to a p5.js instance.

    :param sketch: the p5.js instance.
    :param entry_points: the wrapped functions by entry point name.
    """
    for name, func in entry_points.items():
        setattr(sketch, name, func)


def _noop(*args):
    """
    Detached entry point: do nothing.

    :param ``*args``: ignored.
    """
    pass


# detached handlers are recognized as such from JS (see worker.js)
_noop.__basthon_noop__ = True


def detach(sketch, names=ENTRY_POINTS):
    """
    Detach entry points from a p5.js instance (its DOM listeners remain but
    call nothing). A no-op is used rather than None since p5.js falls back
    to ``window.keyPressed`` (and others) on missing handlers.

    :param sketch: the p5.js instance.
    :param names: the names of the entry points.
    """
    for name in names:
        setattr(sketch, name, _noop)
