"""
A wrapper for p5.js global mode.
This is not intended to be used directly but from
 p5 with from p5 import * .

This is a bit tricky since we have to:
 + get all members names (functions + attributes)
 + exposes them to global scope for import *
 + wrap function that gets a pointer to global instance
 + update attributes (int, str, float, ...) before each call to setup/draw.
This last step is a bit dirty since we modify them (carefully)
directly in the global namespace.
"""

from . import _core  # /!\ do not remove! this ensure p5.js is loaded
from . import _events
from ._nsmanager import NSManager
import js
from pyodide.ffi import JsProxy, to_js as _to_js

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


def isJsProxy(obj):
    """
    Whether an object is a JS object.

    :param obj: the object.
    """
    return isinstance(obj, JsProxy)


def isJsFunc(obj):
    """
    Whether an object is a JS function.

    :param obj: the object.
    """
    return isJsProxy(obj) and callable(obj)


__all__ = ["run", "show", "stop", "load_library", "update_variables"]


def __dir__():
    return __all__


# the global p5.js instance
_instance = None
# the global P5SketchGlobal instance
_wrapped_instance = None
# functions that callback global instance
_wrapped_functions = None
# ignored p5.js functions (avoid conflict with builtins and user entry points)
_ignored_p5_functions = _events.ENTRY_POINTS + (
    "abs",
    "float",
    "hex",
    "int",
    "max",
    "min",
    "pow",
    "print",
    "round",
    "str",
)
_custom_p5_functions = ("filter", "map", "set")


def _p5_members():
    """
    Get the functions and attributes of a p5.js instance (a hidden dummy
    one).

    :return: the members by name.
    """
    # using detached node to ensure canvas is hidden
    node = js.document.createElement("div")
    dummy = js.p5.new(lambda _: None, node)
    members = {
        a: getattr(dummy, a)
        for a in dir(dummy)
        if not a.startswith("_") and a not in _ignored_p5_functions
    }
    dummy.remove()
    return members


# splitting members in functions/attributes
_members = _p5_members()
_functions = set()
_attributes = set()
for k, v in _members.items():
    if isJsProxy(v):
        if isJsFunc(v):
            _functions.add(k)
        else:
            # JsProxy (canvas, drawingContext, pixels, touches) are ignored
            pass
    else:
        _attributes.add(k)


# import * imports functions, attributes and p5.sound classes
__all__ += _functions
__all__ += _attributes
__all__ += _core.sound_classes

# we check for name collision
if len(__all__) != len(set(__all__)):
    duplicate = next(x for x in __all__ if __all__.count(x) > 1)
    raise NameError(f"Internal collision name in p5 for {duplicate}.")


# types implicitly converted by Pyodide when calling JS (no to_js needed)
_implicit_types = (int, float, str, bool, type(None))


class FunctionWrapper(object):
    """
    A function wrapper for p5.js golbal instance functions.
    This is performance critical (called thousands of times per frame).
    """

    def __init__(self, func_name):
        """:param func_name: the name of the p5.js function."""
        self._func_name = func_name
        # method of the global instance (cached while instance is the same)
        self._instance = None
        self._method = None

    def __call__(self, *args):
        """
        Call the function of the global instance (the arguments not converted
        implicitly by Pyodide are converted with ``to_js``).

        :param ``*args``: the function's arguments.
        :return: the function's result.
        """
        if self._instance is not _instance:
            self._instance = _instance
            self._method = getattr(_instance, self._func_name)
        for a in args:
            if type(a) not in _implicit_types:
                args = tuple(_to_js(a) for a in args)
                break
        # calling corresponding function from global instance
        return self._method(*args)


# wrapping functions
_wrapped_functions = {f: FunctionWrapper(f) for f in _functions}
_wrapped_functions.update({c: _core.SoundClass(c) for c in _core.sound_classes})


# custom wrappers
def _custom_filter(*args):
    """
    Python's ``filter`` when called with a function (or ``None``) and an
    iterable, p5.js's ``filter`` otherwise.

    :param ``*args``: the arguments.
    :return: the result of the chosen function.
    """
    if len(args) > 1 and (args[0] is None or callable(args[0])):
        return filter(*args)
    else:
        return _instance.filter(*args)


_wrapped_functions["filter"] = _custom_filter


def _custom_map(*args):
    """
    Python's ``map`` when called with a function and iterables, p5.js's
    ``map`` otherwise.

    :param ``*args``: the arguments.
    :return: the result of the chosen function.
    """
    if len(args) > 1 and callable(args[0]):
        return map(*args)
    else:
        return _instance.map(*args)


_wrapped_functions["map"] = _custom_map


def _custom_set(*args):
    """
    Python's ``set`` when called with at most one argument, p5.js's ``set``
    otherwise.

    :param ``*args``: the arguments.
    :return: the result of the chosen function.
    """
    if len(args) < 2:
        return set(*args)
    else:
        return _instance.set(*args)


_wrapped_functions["set"] = _custom_set


def __getattr__(name):
    """
    Members of the module: attributes are read from the global instance,
    functions are wrapped (see ``_wrapped_functions``).

    :param name: the member's name.
    :return: the member.
    """
    if name in _attributes:
        return getattr(_instance, name) if _instance is not None else None
    elif name in _wrapped_functions:
        return _wrapped_functions[name]
    else:
        try:
            return globals()[name]
        except KeyError:
            raise AttributeError(name)


nsmanager = NSManager(_attributes)


def _update_global_attributes(func):
    """
    Update the p5.js attributes (``width``, ``mouseX``...) in the global
    namespace of a function with the global instance's ones.

    :param func: the user's function.
    """
    nsmanager.update_attributes(_instance, func.__globals__)


def _reset_instance(sketch):
    """
    Replace the global instance (halting the current one).

    :param sketch: the new p5.js instance.
    """
    global _instance
    if _instance is not None:
        # stoping and removing entry points seems OK
        # but if strange things appends, it could be safe
        # to remove it with _instance.remove()
        _core.halt(_instance)
    _instance = sketch


class P5SketchGlobal(_core.P5SketchBase):
    """
    P5 global object derived from core P5SketchBase, see _core.py.
    """

    def _init_sketch(self, sketch):
        """
        Make the sketch the global instance.

        :param sketch: the p5.js instance.
        """
        _reset_instance(sketch)

    def _wrap(self, sketch, entry_points):
        """
        Wrap the user's functions so that the p5.js attributes of their global
        namespace are updated before each call.

        :param sketch: the p5.js instance.
        :param entry_points: the user's functions by entry point name.
        :return: the wrapped functions by entry point name.
        """

        def wrap(f):
            """
            Update the global attributes of ``f`` before calling it.

            :param f: the user's function.
            :return: the wrapped function.
            """
            return _events.wrap(f, before=lambda: _update_global_attributes(f))

        return {name: wrap(f) for name, f in entry_points.items()}


class _HandlerTracker(object):
    """
    Detect stale event handlers in the global namespace.

    The namespace persists between runs, so a handler removed from the
    user code is still there (as the very same object). A handler
    recovered from the namespace is considered stale if it was already
    seen by a previous run, unless the same sketch (same setup and
    draw) is relaunched with this handler.
    """

    def __init__(self):
        """Track nothing yet."""
        # handlers seen in the namespace by previous runs
        self._seen = {}
        # (setup, draw, handlers) of the last run
        self._last = None

    def is_stale(self, name, func, setup, draw):
        """
        Whether a handler found in the namespace is stale.

        :param name: the handler's name.
        :param func: the handler.
        :param setup: the ``setup`` function of the new run.
        :param draw: the ``draw`` function of the new run.
        """
        if self._seen.get(name) is not func:
            return False  # new or redefined
        if self._last is None:
            return True
        last_setup, last_draw, last_handlers = self._last
        same_sketch = last_setup is setup and last_draw is draw
        return not (same_sketch and last_handlers.get(name) is func)

    def see(self, name, func):
        """
        Remember a handler found in the namespace.

        :param name: the handler's name.
        :param func: the handler.
        """
        self._seen[name] = func

    def ran(self, setup, draw, handlers):
        """
        Remember the last run.

        :param setup: its ``setup`` function.
        :param draw: its ``draw`` function.
        :param handlers: its event handlers by name.
        """
        self._last = (setup, draw, dict(handlers))


_handler_tracker = _HandlerTracker()


def run(setup=None, draw=None, preload=None, **handlers):
    """
    Run a new sketch (the previous one is stopped). The functions omitted
    are taken from the global namespace.

    Event handlers (``mousePressed``, ``keyPressed``...) are taken from the
    global namespace or can be passed as keyword arguments (e.g.
    ``run(mousePressed=on_click)``). Passing ``None`` disables one.

    :param setup: the function called once at the start.
    :param draw: the function called at each frame.
    :param preload: the function called before ``setup`` (e.g. to load
        files), not taken from the global namespace.
    :param ``**handlers``: the event handlers by name.
    """
    global _wrapped_instance

    # trying to recover setup and draw from global namespace
    if setup is None:
        setup = nsmanager.get_from_global_ns("setup")
    if draw is None:
        draw = nsmanager.get_from_global_ns("draw")
    # preload is not recovered from global namespace
    # otherwise next sketch will get previous preload

    # trying to recover event handlers from global namespace
    # (stale ones, i.e. removed from user code, are ignored)
    _events.check_names(handlers)
    from_ns = {}
    for name in _events.EVENT_HANDLERS:
        if name not in handlers:
            func = nsmanager.get_from_global_ns(name)
            if callable(func):
                from_ns[name] = func
                if not _handler_tracker.is_stale(name, func, setup, draw):
                    handlers[name] = func

    _wrapped_instance = P5SketchGlobal(setup, draw, preload, handlers).run()

    for name, func in from_ns.items():
        _handler_tracker.see(name, func)
    _handler_tracker.ran(setup, draw, handlers)


show = run


def stop():
    """
    Stop the global sketch (no more calls to draw nor to the event
    handlers).
    """
    return _wrapped_instance.stop()


def load_library(url):
    """
    Load a JavaScript library (e.g. a p5.js add-on) with its URL.

    :param url: the library's URL.
    :return: a promise resolved once the library is loaded.
    """
    return _core.load_library(url)


def update_variables():
    """
    Update the p5.js variables of the global namespace, e.g. ``width`` and
    ``height`` after ``createCanvas`` (they are otherwise updated before each
    call to ``setup`` and ``draw``).
    """
    nsmanager.update_attributes(_instance)
