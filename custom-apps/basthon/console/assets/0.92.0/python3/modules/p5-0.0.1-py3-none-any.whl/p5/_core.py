"""
Core part of p5 wrapper. p5.js loading is done here.

In legacy mode, p5.js runs in the main thread and the sketch canvas
is directly displayed. In isolated mode (worker), p5.js runs on top
of a DOM emulation and the sketch is displayed in a kernel iframe
(see worker.js and iframe.html).
"""

from importlib.resources import files as _files
import sys
import js
from basthon import kernel
from pyodide.ffi import create_proxy as _create_proxy, to_js as _to_js
from . import _events

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = [
    "P5SketchBase",
    "load_library",
    "close_display",
    "halt",
    "sound_classes",
    "SoundClass",
]


def __dir__():
    return __all__


_legacy = js.basthon.isLegacy()


def _read(filename):
    """
    Read a file of the p5 package.

    :param filename: the file's path in the package.
    :return: the file's content (text).
    """
    with (_files("p5") / filename).open() as f:
        return f.read()


if not _legacy:
    if not hasattr(js, "OffscreenCanvas"):
        raise ImportError("p5 module requires OffscreenCanvas support in browser.")
    _iframe_html = _read("bundle/iframe.html")


def _report_error(message):
    """
    Show an error of p5.js to the user (e.g. an image that can't be
    loaded), otherwise only logged in the browser's console.

    :param message: the error's message.
    """
    print(message, file=sys.stderr)


# p5.js patches and, in isolated mode, DOM emulation (before p5.js)
if not hasattr(js, "basthonP5"):
    js.eval(_read("bundle/worker.js"))

# loading p5.js and p5.sound (its objects are tagged with the execution
# count, see halt)
if not hasattr(js, "p5"):
    js.eval(_read("p5.min.js"))
    js.basthonP5.loadSoundAddon(
        _read("p5.sound.min.js"), _create_proxy(kernel.execution_count)
    )
    js.basthonP5.patch(js.p5, _create_proxy(_report_error))

# names of the classes of p5.sound (SoundFile, Oscillator, ...)
sound_classes = tuple(js.basthonP5.soundClasses)


# p5.js instances not deleted yet: their drawing loop and event
# listeners outlive a (lazy) kernel restart, so they are halted
# when the kernel stops, otherwise they would keep calling back
# user functions whose namespace was cleared
_sketches = js.Set.new()  # JS set: JsProxy objects are not hashable


def halt(sketch):
    """
    Stop a p5.js instance: no more call to draw nor event handlers,
    no more display (the last frame remains), no more camera and no more
    sound (but the one created by the running code, e.g. for a new sketch).

    :param sketch: the p5.js instance.
    """
    _sketches.delete(sketch)
    sketch.noLoop()
    # draw is also detached since p5.js calls it a last time
    # after noLoop if a frame was already requested
    _events.detach(sketch)
    close_display(sketch)
    # the sketch won't run anymore: its cameras are released
    js.basthonP5.releaseCameras(sketch)
    # p5.sound objects are not bound to a sketch
    js.basthonP5.stopSounds(kernel.execution_count())


def _halt_all():
    """Halt all the sketches and stop all the sounds (when the kernel stops)."""
    for sketch in list(_sketches.values()):
        halt(sketch)
    js.basthonP5.stopSounds()


kernel.on_stop(_halt_all)


def close_display(sketch):
    """
    Stop displaying a sketch (the last frame remains).
    Only useful in isolated mode.

    :param sketch: the p5.js instance.
    """
    if not _legacy:
        js.basthonP5.close(sketch)


class P5SketchBase(object):
    """
    P5 instance object that you can run and stop. Most of the time,
    this object is not build manualy but used as the return of p5.run.
    """

    def __init__(self, setup, draw, preload=None, handlers=None):
        """
        :param setup: the function called once at the start.
        :param draw: the function called at each frame.
        :param preload: the function called before ``setup`` (e.g. to load
            files), if any.
        :param handlers: the event handlers (e.g. ``mousePressed``) by name.
        """
        if setup is None:
            raise ValueError("P5: setup function not set!")
        if draw is None:
            raise ValueError("P5: draw function not set!")
        handlers = handlers or {}
        _events.check_names(handlers)
        entry_points = {"preload": preload, "setup": setup, "draw": draw}
        entry_points.update(handlers)
        # user functions (not wrapped) by entry point name
        self._entry_points = {k: f for k, f in entry_points.items() if f is not None}
        # wrapped entry points (set when p5.js builds the sketch)
        self._wrapped = None
        self._node = None
        self._sketch = None

    def _init_sketch(self, sketch):
        """
        Called first when p5.js builds the sketch.

        :param sketch: the p5.js instance.
        """
        pass

    def _wrap(self, sketch, entry_points):
        """
        Wrap user entry points to be called back by p5.js.

        :param sketch: the p5.js instance.
        :param entry_points: the user's functions by entry point name.
        :return: the wrapped functions by entry point name.
        """
        raise NotImplementedError

    def _builder(self, entry_points):
        """
        Function given to p5.js to build the sketch: it attaches the wrapped
        entry points to the p5.js instance.

        :param entry_points: the user's functions by entry point name.
        :return: the function, taking the p5.js instance.
        """

        def func(sketch):
            self._init_sketch(sketch)
            self._wrapped = self._wrap(sketch, entry_points)
            _events.attach(sketch, self._wrapped)

        return func

    def run(self):
        """
        Start the sketch, or resume it after ``stop``.

        :return: the sketch.
        """
        if self._sketch is not None:
            # resuming: event handlers were detached by stop
            _events.attach(self._sketch, self._wrapped)
            self._sketch.loop()
            return self

        build_func = self._builder(self._entry_points)

        if not _legacy:
            # displaying in a kernel iframe
            node = js.basthonP5.createRoot()
            self._sketch = js.p5.new(build_func, node)
            _sketches.add(self._sketch)
            port = js.basthon.displayKernelIFrame(_iframe_html)
            js.basthonP5.connect(self._sketch, port)
            self._node = node
            return self

        # new node that will contains canvas
        node = js.document.createElement("div")
        node.style.width = "100%"
        node.style.textAlign = "center"

        # main p5 call: create canvas and start drawing
        self._sketch = js.p5.new(build_func, node)
        _sketches.add(self._sketch)

        # fix: in 3D, a blank canvas is added before... remove it
        while len(node.children) > 1:
            node.removeChild(node.children[0])

        # by default, node is hidden
        for n in node.children:
            n.style.visibility = "visible"

        # sending node to Basthon for rendering
        js.basthon.display(node)
        self._node = node
        return self

    def stop(self):
        """
        Stop the calls to draw and to the event handlers (the sketch can be
        resumed with ``run``).
        """
        if self._sketch is not None:
            self._sketch.noLoop()
            _events.detach(self._sketch, _events.EVENT_HANDLERS)

    def delete(self):
        """Delete the sketch and its canvas."""
        if self._sketch is not None:
            _sketches.delete(self._sketch)
            close_display(self._sketch)
            self._sketch.remove()
        if self._node is not None:
            if not _legacy:
                js.basthonP5.removeRoot(self._node)
            elif self._node.parentNode is not None:
                self._node.parentNode.removeChild(self._node)


class SoundClass(object):
    """
    A class of p5.sound (e.g. SoundClass("Oscillator")): calling it
    creates an object, as new p5.Oscillator(...) in JS.
    """

    def __init__(self, name):
        """:param name: the class's name in p5.js (e.g. ``"Oscillator"``)."""
        self.__name__ = self.__qualname__ = name

    def __repr__(self):
        return f"<p5.sound class {self.__name__}>"

    def __call__(self, *args):
        """
        Create an object of the class (callable arguments are kept alive, e.g.
        ``SoundLoop(callback)``).

        :param ``*args``: the constructor's arguments.
        :return: the p5.sound object.
        """
        # callbacks are kept alive (e.g. SoundLoop(callback))
        args = (_create_proxy(a) if callable(a) else _to_js(a) for a in args)
        return getattr(js.p5, self.__name__).new(*args)


def load_library(url):
    """
    Load a JavaScript library (e.g. a p5.js add-on) with its URL.

    :param url: the library's URL.
    :return: a promise resolved once the library is loaded.
    """
    return js.Basthon.loadScript(url)
