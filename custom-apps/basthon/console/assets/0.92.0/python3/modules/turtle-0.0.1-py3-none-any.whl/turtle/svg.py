# Modified version of Brython's SVG module
# Author: Romain Casati
# License: GPL v3 or higher

from __future__ import annotations

from html import escape

_svg_ns = "http://www.w3.org/2000/svg"
_xlink_ns = "http://www.w3.org/1999/xlink"

_svg_tags = [
    "a",
    "altGlyph",
    "altGlyphDef",
    "altGlyphItem",
    "animate",
    "animateColor",
    "animateMotion",
    "animateTransform",
    "circle",
    "clipPath",
    "color_profile",  # instead of color-profile
    "cursor",
    "defs",
    "desc",
    "ellipse",
    "feBlend",
    "foreignObject",  # patch to enable foreign objects
    "g",
    "image",
    "line",
    "linearGradient",
    "marker",
    "mask",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialGradient",
    "rect",
    "set",
    "stop",
    "svg",
    "text",
    "title",
    "inner-text",
    "tref",
    "tspan",
    "use",
]


class Element:
    """An SVG element, rendered as text by ``str``."""

    def __init__(self, tag: str, ns=None, value=None):
        """
        :param tag: the element's tag (``"inner-text"`` for a text node).
        :param ns: the element's namespace (set as ``xmlns`` for ``svg``).
        :param value: the element's text.
        """
        self._tag = tag
        self._value = value
        self._ns = ns
        self._attributes: dict[str, str] = {}
        self._children: list[Element] = []
        self._parent: Element | None = None
        # this is mandatory to display svg properly
        if tag == "svg" and ns is not None:
            self.setAttribute("xmlns", ns)
            self.setAttribute("xmlns:xlink", _xlink_ns)

    def setAttribute(self, attribute: str, value: str):
        """
        Set an attribute.

        :param attribute: the attribute's name.
        :param value: its value.
        """
        self.setAttributeNS(None, attribute, value)

    def setAttributeNS(self, ns: str | None, attribute: str, value: str):
        """
        Set an attribute in a namespace.

        :param ns: the namespace, ``None`` for none.
        :param attribute: the attribute's name.
        :param value: its value.
        """
        key = attribute
        if ns == _xlink_ns:
            key = f"xlink:{key}"
        elif ns is not None:
            key = f"{ns}:{key}"
        self._attributes[key] = value

    def getAttribute(self, attribute: str):
        """
        Value of an attribute.

        :param attribute: the attribute's name.
        :return: its value, ``None`` if not set.
        """
        return self._attributes.get(attribute)

    def appendChild(self, child: Element):
        """
        Add a child element at the end.

        :param child: the element.
        """
        self._children.append(child)
        child._parent = self

    def insertBefore(self, child: Element, reference: Element | None):
        """
        Add a child element before another one.

        :param child: the element.
        :param reference: the child before which it is added, ``None`` to
            add it at the end.
        """
        if reference is None:
            self.appendChild(child)
            return
        self._children.insert(self._children.index(reference), child)
        child._parent = self

    def removeChild(self, other: Element):
        """
        Remove a child element.

        :param other: the element.
        """
        self._children.remove(other)
        other._parent = None

    @property
    def parentNode(self) -> Element | None:
        """The parent element, ``None`` if it has none."""
        return self._parent

    def addEventListener(self, event, callback):
        """
        Ignored (compatibility with Brython's DOM elements).

        :param event: the event's name.
        :param callback: the listener.
        """
        pass

    def render_attributes(self) -> str:
        """
        Attributes as in an XML tag (``1.0`` written ``1``).

        :return: the attributes' text.
        """

        # remove .0 part for int
        def filter(x):
            if isinstance(x, float) and int(x) == x:
                x = int(x)
            return escape(x) if isinstance(x, str) else str(x)

        return " ".join(f'{k}="{filter(v)}"' for k, v in self._attributes.items())

    def __str__(self) -> str:
        if self._tag == "inner-text":
            return escape(str(self._value), quote=False)
        attributes = self.render_attributes()
        open_tag = f"<{self._tag} {attributes}>" if attributes else f"<{self._tag}>"
        close_tag = f"</{self._tag}>"
        content = "".join(str(e) for e in self._children)
        if self._value is not None:
            content += escape(str(self._value), quote=False)
        return f"{open_tag}{content}{close_tag}"


def _tag_func(tag):
    """
    Function creating an SVG element (e.g. ``circle(cx=0, cy=0, r=10)``):
    positional arguments are its children (text for strings and numbers),
    keyword arguments its attributes (``_`` written ``-``, ``Id`` and ``From``
    for ``id`` and ``from``, ``style`` given as a dict, ``None`` values
    ignored).

    :param tag: the element's tag.
    :return: the function.
    """

    def func(*args, **kwargs):
        node = Element(tag, ns=_svg_ns)
        for arg in args:
            if isinstance(arg, (str, int, float)):
                arg = Element("inner-text", value=str(arg))
            node.appendChild(arg)
        for key, value in kwargs.items():
            # SVG attributes are case sensitive (viewBox, attributeName...)
            if key in ("Id", "From"):
                key = key.lower()
            if key[0:2].lower() == "on":
                # Event binding passed as argument "onclick", "onfocus"...
                # Better use method bind of DOMNode objects
                node.addEventListener(key[2:].lower(), value)
            elif key == "style":
                node.setAttribute(
                    "style", ";".join(f"{k}: {v}" for k, v in value.items())
                )
            elif "href" in key:
                node.setAttributeNS(_xlink_ns, "href", value)
            elif value is not False and value is not None:
                # option.selected=false sets it to true :-)
                node.setAttributeNS(None, key.replace("_", "-"), value)
        return node

    return func


for tag in _svg_tags:
    vars()[tag] = _tag_func(tag)
