# A port of the Brython's Turtle module to Basthon by Romain Casati
# under the GPLv3 License.
#
# A revised version of CPython's turtle module written for Brython
#

# The drawing is an SVG scene, animated with SMIL animations: each drawing
# action is a "frame", an animation starting at the end of the previous one.
# Without animation (``animation("off")``), the scene is a static SVG.
#
# All public methods/functions of the CPython version exist, if only to print
# out a warning that they are not implemented (the event handlers: the scene
# is computed before being displayed). The intent is to make it easier to
# "port" any existing turtle program from CPython to the browser.
#
# IMPORTANT: If we have a turtle at an angle of 350 degrees and we rotate it
# by an additional 20 degrees, its shape is rotated to 370 degrees, not 10:
# when "slowly" animated, a rotation from 350 to 10 degrees would turn the
# wrong way.

import functools
import inspect
import math
import sys

from math import cos, sin
from uuid import uuid4

from . import svg as SVG


def appendTo(root, node):
    """
    Append an SVG element to another.

    :param root: the parent element.
    :param node: the appended element.
    """
    root.appendChild(node)


# Even though it is a private object, use the same name for the configuration
# dict as the CPython's module.


# Commented out configuration items are those found on the CPython version
def _default_cfg():
    """
    Default configuration (as CPython's ``_CFG``; the items commented out
    are not supported).

    :return: the configuration.
    """
    return {
        # "width" : 0.5,               # Screen
        # "height" : 0.75,
        "canvwidth": 640,
        "canvheight": 480,
        # "leftright": None,
        # "topbottom": None,
        "mode": "standard",
        "colormode": 1.0,
        "delay": 10,
        "undobuffersize": 1000,
        "shape": "turtle",
        "pencolor": "black",
        "fillcolor": "black",
        "resizemode": "noresize",
        "visible": True,
        # "language": "english",        # docstrings
        # "exampleturtle": "turtle",
        # "examplescreen": "screen",
        # "title": "Python Turtle Graphics",
        # "using_IDLE": False
        # Below are configuration items specific to this version
        "min_duration": "1ms",
    }


_CFG = _default_cfg()


def set_defaults(**params):
    """
    Override configuration values (``canvwidth``, ``canvheight``, ``mode``,
    ``colormode``, ``shape``, ``pencolor``, ``fillcolor``, ``resizemode``,
    ``visible``, ``min_duration``...) and start a new scene.

    :param ``**params``: the values by name.
    """
    _CFG.update(**params)
    Screen()._new_scene()


def _round(value):
    """
    Round an SVG coordinate (no ``-0``, integers written without decimals).

    :param value: the number.
    :return: the rounded number.
    """
    value = round(value, 4) + 0.0
    return int(value) if value.is_integer() else value


class Vec2D(tuple):
    """
    A two-dimensional vector (as CPython's), e.g. the turtle's position:
    ``a + b``, ``a - b``, ``a * b`` (dot product), ``k * a``, ``a * k``,
    ``abs(a)``, ``-a`` and ``a.rotate(angle)``.
    """

    def __new__(cls, x, y):
        """
        :param x: the first coordinate.
        :param y: the second coordinate.
        """
        return tuple.__new__(cls, (x, y))

    def __add__(self, other):
        return Vec2D(self[0] + other[0], self[1] + other[1])

    def __mul__(self, other):
        if isinstance(other, Vec2D):
            return self[0] * other[0] + self[1] * other[1]
        return Vec2D(self[0] * other, self[1] * other)

    def __rmul__(self, other):
        if isinstance(other, (int, float)):
            return Vec2D(self[0] * other, self[1] * other)
        return NotImplemented

    def __sub__(self, other):
        return Vec2D(self[0] - other[0], self[1] - other[1])

    def __neg__(self):
        return Vec2D(-self[0], -self[1])

    def __abs__(self):
        return math.hypot(*self)

    def rotate(self, angle):
        """
        Rotate the vector counterclockwise.

        :param angle: the angle (in degrees).
        :return: the rotated vector.
        """
        perp = Vec2D(-self[1], self[0])
        angle = math.radians(angle)
        c, s = math.cos(angle), math.sin(angle)
        return Vec2D(self[0] * c + perp[0] * s, self[1] * c + perp[1] * s)

    def __getnewargs__(self):
        return (self[0], self[1])

    def __repr__(self):
        return "(%.2f,%.2f)" % self


# backward compatibility
FormattedTuple = Vec2D


def _point(x, y=None):
    """
    A point from two coordinates, a pair or a turtle.

    :param x: the first coordinate, a pair of coordinates or a turtle.
    :param y: the second coordinate.
    :return: the point.
    """
    if y is not None:
        return Vec2D(x, y)
    if isinstance(x, TNavigator):
        return x.pos()
    x, y = x
    return Vec2D(x, y)


def create_circle(r):
    """
    Create an SVG circle centered at the origin.

    :param r: its radius.
    :return: the circle.
    """
    return SVG.circle(cx=0, cy=0, r=r)


def create_polygon(points):
    """
    Create an SVG polygon (the points in SVG coordinates).

    :param points: its vertices (pairs of coordinates).
    :return: the polygon.
    """
    points = " ".join(f"{_round(x)},{_round(y)}" for x, y in points)
    return SVG.polygon(points=points)


def create_rectangle(width=2, height=2, rx=None, ry=None):
    """
    Create an SVG rectangle centered at the origin.

    :param width: its width.
    :param height: its height.
    :param rx: the horizontal radius of rounded corners, if any.
    :param ry: the vertical radius of rounded corners, if any.
    :return: the rectangle.
    """
    return SVG.rect(
        x=-width / 2, y=-height / 2, width=width, height=height, rx=rx, ry=ry
    )


def create_square(size=2, r=None):
    """
    Create an SVG square centered at the origin.

    :param size: its side.
    :param r: the radius of rounded corners, if any.
    :return: the square.
    """
    return create_rectangle(width=size, height=size, rx=r, ry=r)


class TurtleGraphicsError(Exception):
    """Some TurtleGraphics Error"""

    pass


class Terminator(Exception):
    """
    Raised by CPython when the turtle window is closed (never raised here,
    for programs catching it).
    """

    pass


def _image(filename):
    """
    Read a GIF or PNG image file.

    :param filename: the file's name.
    :return: its data URL, width and height.
    """
    import base64

    with open(filename, "rb") as f:
        data = f.read()
    if data[:4] == b"GIF8":
        mime = "image/gif"
        width = int.from_bytes(data[6:8], "little")
        height = int.from_bytes(data[8:10], "little")
    elif data[:8] == b"\x89PNG\r\n\x1a\n":
        mime = "image/png"
        width = int.from_bytes(data[16:20], "big")
        height = int.from_bytes(data[20:24], "big")
    else:
        raise TurtleGraphicsError(f"Image {filename} is not a GIF nor a PNG file.")
    url = f"data:{mime};base64," + base64.b64encode(data).decode()
    return url, width, height


class Shape:
    """
    A turtle's shape: ``"polygon"`` (a tuple of points), ``"image"`` (a
    GIF or PNG file name) or ``"compound"`` (polygons added by
    ``addcomponent``). Its points are in the turtle's frame: heading towards
    positive y, x on its right.
    """

    def __init__(self, type_, data=None):
        """
        :param type_: ``"polygon"``, ``"image"`` or ``"compound"``.
        :param data: the points of a polygon, the file of an image.
        """
        self._type = type_
        if type_ == "polygon":
            if isinstance(data, list):
                data = tuple(data)
        elif type_ == "image":
            if isinstance(data, str):
                data = _image(data)
        elif type_ == "compound":
            data = []
        else:
            raise TurtleGraphicsError("There is no shape type %s" % type_)
        self._data = data

    def addcomponent(self, poly, fill, outline=None):
        """
        Add a polygon to a compound shape.

        :param poly: its points.
        :param fill: its fill color.
        :param outline: its outline color (the fill color if ``None``).
        """
        if self._type != "compound":
            raise TurtleGraphicsError("Cannot add component to %s Shape" % self._type)
        if outline is None:
            outline = fill
        self._data.append([poly, fill, outline])


def _builtin_shapes():
    """
    The shapes available at start (CPython's ones).

    :return: the shapes by name.
    """
    shapes = {
        "arrow": Shape("polygon", ((-10, 0), (10, 0), (0, 10))),
        "turtle": Shape(
            "polygon",
            (
                (0, 16),
                (-2, 14),
                (-1, 10),
                (-4, 7),
                (-7, 9),
                (-9, 8),
                (-6, 5),
                (-7, 1),
                (-5, -3),
                (-8, -6),
                (-6, -8),
                (-4, -5),
                (0, -7),
                (4, -5),
                (6, -8),
                (8, -6),
                (5, -3),
                (7, 1),
                (6, 5),
                (9, 8),
                (7, 9),
                (4, 7),
                (1, 10),
                (2, 14),
            ),
        ),
        "classic": Shape("polygon", ((0, 0), (-5, -9), (0, -7), (5, -9))),
        "triangle": Shape("polygon", ((10, -5.77), (0, 11.55), (-10, -5.77))),
        "square": Shape("polygon", ((10, -10), (10, 10), (-10, 10), (-10, -10))),
        "circle": Shape(
            "polygon",
            tuple(
                (
                    round(10 * math.cos(math.radians(18 * i)), 2),
                    round(10 * math.sin(math.radians(18 * i)), 2),
                )
                for i in range(20)
            ),
        ),
        "blank": Shape("image", None),
    }
    # nicer SVG elements than polygons
    shapes["square"]._svg = lambda: create_square(20)
    shapes["circle"]._svg = lambda: create_circle(10)
    return shapes


class _StaticFrame:
    """A drawing action without animation: changes are applied at once."""

    def set(self, element, attribute, value):
        element.setAttribute(attribute, value)

    def animate(self, element, attribute, from_, to, seconds=0):
        element.setAttribute(attribute, to)

    def transform(self, element, type_, from_, to, seconds=0):
        element.setAttribute("transform", f"{type_}({to})")

    def appear(self, element):
        pass

    def disappear(self, element):
        if element.parentNode is not None:
            element.parentNode.removeChild(element)

    def close(self):
        pass


class _AnimFrame:
    """
    A drawing action, a set of animations starting together. The longest one
    gets the frame's id (the next frame starts at its end).
    """

    def __init__(self, screen, begin, id_, instant=False):
        """
        :param screen: the screen.
        :param begin: the animations' start.
        :param id_: the frame's id, ``None`` for none.
        :param instant: whether the animations last the minimum duration.
        """
        self.screen = screen
        self.begin = begin
        self.id = id_
        self.instant = instant
        self._anims = []

    def dur(self, seconds):
        """
        Duration of an animation.

        :param seconds: the duration in seconds.
        :return: the SMIL duration.
        """
        if self.instant or seconds < 0.001:
            return _CFG["min_duration"]
        return "%.3fs" % seconds

    def _add(self, element, anim, seconds):
        anim.setAttribute("begin", self.begin)
        appendTo(element, anim)
        self._anims.append((0 if self.instant else seconds, anim))

    def set(self, element, attribute, value):
        """
        Set an attribute.

        :param element: the element.
        :param attribute: the attribute's name.
        :param value: its value.
        """
        anim = SVG.set(
            attributeName=attribute, to=value, dur=_CFG["min_duration"], fill="freeze"
        )
        self._add(element, anim, 0)

    def animate(self, element, attribute, from_, to, seconds=0):
        """
        Change an attribute progressively.

        :param element: the element.
        :param attribute: the attribute's name.
        :param from_: its first value.
        :param to: its last value.
        :param seconds: the animation's duration.
        """
        anim = SVG.animate(
            attributeName=attribute,
            From=from_,
            to=to,
            dur=self.dur(seconds),
            fill="freeze",
        )
        self._add(element, anim, seconds)

    def transform(self, element, type_, from_, to, seconds=0):
        """
        Change the transform of an element progressively.

        :param element: the element.
        :param type_: ``"translate"``, ``"rotate"``, ``"scale"`` or
            ``"skewX"``.
        :param from_: its first value.
        :param to: its last value.
        :param seconds: the animation's duration.
        """
        anim = SVG.animateTransform(
            attributeName="transform",
            type=type_,
            From=from_,
            to=to,
            dur=self.dur(seconds),
            fill="freeze",
        )
        self._add(element, anim, seconds)

    def appear(self, element):
        """
        Display an element from this frame.

        :param element: the element.
        """
        element.setAttribute("display", "none")
        self.set(element, "display", "inline")

    def disappear(self, element):
        """
        Hide an element from this frame.

        :param element: the element.
        """
        self.set(element, "display", "none")

    def close(self):
        """Give the frame's id to its longest animation."""
        if self.id is None:
            return
        if self._anims:
            anim = max(self._anims, key=lambda a: a[0])[1]
            anim.setAttribute("id", self.id)
        else:
            self.screen._timing_anim(self.begin, self.id)
        self.id = None


class Singleton(type):
    """Metaclass of the classes with a single instance (``Screen``)."""

    _instances = {}

    def __call__(cls, *args, **kwargs):
        """
        Create the class's instance the first time, return it afterwards.

        :param ``*args``: the constructor's arguments (first call only).
        :param ``**kwargs``: the constructor's keyword arguments (first call
            only).
        :return: the instance.
        """
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


def _warn_not_implemented(name):
    """
    Print a warning for a function that can't be implemented.

    :param name: the function's name.
    """
    sys.stderr.write(f"Warning: {name}() is not implemented.\n")


class Screen(metaclass=Singleton):
    """
    The drawing, an animated SVG scene displayed by ``done`` (a single
    instance).
    """

    def __init__(self):
        """Create the screen with the available turtle shapes and a new scene."""
        self._shapes = _builtin_shapes()
        self._animate = True
        self._old_svg_scene = None
        self._generation = 0
        self._frame = None
        self._new_scene()

    def animation(self, onoff):
        """
        Enable or disable the animation: without it, the final drawing is
        displayed at once (and the SVG file is portable).

        :param onoff: ``"on"`` or ``"off"``.
        """
        onoff = onoff.lower()
        if onoff == "on":
            self._animate = True
        elif onoff == "off":
            self._animate = False
        else:
            raise ValueError("Supported values are only 'on' and 'off'.")

    def tracer(self, n=None, delay=None):
        """
        Enable (``n`` not 0) or disable (``n`` is 0) the animation, as
        ``animation``.

        :param n: 0 to disable the animation, ``None`` to return its state.
        :param delay: ignored.
        :return: 1 if the animation is enabled, 0 otherwise, if ``n`` is
            ``None``.
        """
        if n is None:
            return 1 if self._animate else 0
        self.animation("on" if n else "off")

    def update(self):
        """Do nothing (the drawing is displayed by ``done``)."""
        pass

    def delay(self, delay=None):
        """
        Set or return the drawing delay (no effect: use ``speed``).

        :param delay: the delay in milliseconds, ``None`` to return it.
        :return: the delay, if ``delay`` is ``None``.
        """
        if delay is None:
            return self._delayvalue
        self._delayvalue = int(delay)

    def _repr_svg_(self):
        """
        SVG of the last scene ended by ``done``.

        :return: the SVG text, ``None`` if no scene ended.
        """
        if self._old_svg_scene is None:
            return None
        return str(self._old_svg_scene)

    def svg(self):
        """
        SVG of the last scene ended by ``done``.

        :return: the SVG text.
        """
        if self._old_svg_scene is None:
            raise RuntimeError("No turtle scene ended! You should call 'done' first.")
        return self._repr_svg_()

    def save(self, file):
        """
        Save the SVG of the last scene ended by ``done`` to a file.

        :param file: a file name, or a file object opened in text mode.
        """
        html = self.svg()
        if isinstance(file, str):
            with open(file, "w") as f:
                f.write(html)
        else:
            # file should be a file descriptor
            file.write(html)

    def animation_frame_id(self, index):
        """
        Id of an animation frame (animations start at the end of the previous
        frame).

        :param index: the frame's index.
        :return: the id.
        """
        return "af_{}_{}".format(self.svg_id, index)

    def _timing_anim(self, begin, id_):
        """
        Add an animation for timing purpose only.

        :param begin: its start.
        :param id_: its id.
        """
        anim = SVG.set(
            Id=id_,
            attributeName="visibility",
            to="hidden",
            begin=begin,
            dur=_CFG["min_duration"],
            fill="freeze",
        )
        appendTo(self._timing, anim)

    def _static(self):
        """Whether the drawing actions are applied without animations."""
        return not (self._animate or self._animated)

    def _next_frame(self):
        """
        Start a new drawing action.

        :return: the frame, to which animations are added.
        """
        self._close_frame()
        if self._animate:
            self._instant_id = None
            self._animated = True
            begin = self.animation_frame_id(self.frame_index) + ".end"
            self.frame_index += 1
            frame = _AnimFrame(self, begin, self.animation_frame_id(self.frame_index))
        elif self._animated:
            # animation disabled after animations: everything at once
            if self._instant_id is None:
                begin = self.animation_frame_id(self.frame_index) + ".end"
                self.frame_index += 1
                self._instant_id = self.animation_frame_id(self.frame_index)
                self._timing_anim(begin, self._instant_id)
            frame = _AnimFrame(self, self._instant_id + ".begin", None, instant=True)
        else:
            frame = _StaticFrame()
        self._frame = frame
        return frame

    def _close_frame(self):
        """End the current drawing action."""
        if self._frame is not None:
            self._frame.close()
            self._frame = None

    def bgcolor(self, *args):
        """
        Set or return the background color.

        :param ``*args``: a color (a string in any format of the browser or a
            tuple ``(r, g, b)``), three numbers ``r, g, b``, or nothing to
            return it.
        :return: the background color, without argument.
        """
        if not args:
            return self._color(self._bgcolor)
        self._bgcolor = self._colorstr(args)
        frame = self._next_frame()
        if self._bg_rect is None:
            self._bg_rect = SVG.rect(
                x="-50%", y="-50%", width="100%", height="100%", fill="none"
            )
            children = self.background_canvas._children
            self.background_canvas.insertBefore(
                self._bg_rect, children[0] if children else None
            )
        frame.set(self._bg_rect, "fill", self._css(self._bgcolor))

    def bgpic(self, picname=None):
        """
        Set or return the background image, centered.

        :param picname: a GIF or PNG file name, ``"nopic"`` to remove it,
            ``None`` to return it.
        :return: the image's name (``"nopic"`` for none), if ``picname`` is
            ``None``.
        """
        if picname is None:
            return self._bgpicname
        frame = self._next_frame()
        if self._bgpic is not None:
            frame.disappear(self._bgpic)
            self._bgpic = None
        if picname != "nopic":
            url, width, height = _image(picname)
            self._bgpic = SVG.image(
                href=url, x=-width / 2, y=-height / 2, width=width, height=height
            )
            appendTo(self.background_canvas, self._bgpic)
            frame.appear(self._bgpic)
        self._bgpicname = picname

    def colormode(self, cmode=None):
        """
        Set or return the color mode: the maximum of the ``r, g, b`` values
        of the colors.

        :param cmode: 1.0 or 255, ``None`` to return it.
        :return: the color mode, if ``cmode`` is ``None``.
        """
        if cmode is None:
            return self._colormode
        if cmode == 1.0:
            self._colormode = float(cmode)
        elif cmode == 255:
            self._colormode = int(cmode)

    def _colorstr(self, color):
        """
        Check a color and convert it to a string.

        :param color: the arguments giving the color (a string, a tuple
            ``(r, g, b)`` or three numbers).
        :return: the color string (``#rrggbb`` for numbers).
        """
        if len(color) == 1:
            color = color[0]
        if isinstance(color, str):
            return color
        try:
            r, g, b = color
        except (TypeError, ValueError):
            raise TurtleGraphicsError("bad color arguments: %s" % str(color))
        if self._colormode == 1.0:
            r, g, b = [255.0 * x for x in (r, g, b)]
        if not ((0 <= r <= 255) and (0 <= g <= 255) and (0 <= b <= 255)):
            raise TurtleGraphicsError("bad color sequence: %s" % str(color))
        return "#%02x%02x%02x" % (round(r), round(g), round(b))

    def _color(self, cstr):
        """
        A color as returned to the user: a tuple for ``#rrggbb`` strings.

        :param cstr: the color string.
        :return: the color.
        """
        if not cstr.startswith("#"):
            return cstr
        if len(cstr) == 7:
            cl = [int(cstr[i : i + 2], 16) for i in (1, 3, 5)]
        elif len(cstr) == 4:
            cl = [16 * int(cstr[h], 16) for h in cstr[1:]]
        else:
            return cstr
        return tuple(c * self._colormode / 255 for c in cl)

    @staticmethod
    def _css(cstr):
        """
        A color for the browser (Tk names with spaces and ``grayNN`` are
        converted).

        :param cstr: the color string.
        :return: the CSS color.
        """
        name = cstr.replace(" ", "").lower()
        if name[:4] in ("gray", "grey") and name[4:].isdigit():
            level = round(int(name[4:]) * 255 / 100)
            return "#%02x%02x%02x" % (level, level, level)
        if " " in cstr and name.isalpha():
            return name
        return cstr

    def _to_svg(self, x, y):
        """
        Convert turtle coordinates to SVG ones (the origin at the center, the
        y-coordinate increasing towards the bottom of the screen).

        :param x: the first coordinate.
        :param y: the second coordinate.
        :return: the SVG coordinates.
        """
        return (
            _round((x - self._x0) * self._xscale),
            _round((self._y0 - y) * self._yscale),
        )

    def _screen_angle(self, angle):
        """
        Direction on the screen of a turtle's heading.

        :param angle: the heading (in degrees, counterclockwise from east).
        :return: the SVG angle (in degrees, clockwise from east).
        """
        a = math.radians(angle)
        return math.degrees(
            math.atan2(-math.sin(a) * self._yscale, math.cos(a) * self._xscale)
        )

    def mode(self, mode=None):
        """
        Set or return the mode, resetting the turtles: ``"standard"``
        (heading 0 towards east, counterclockwise angles), ``"logo"``
        (heading 0 towards north, clockwise angles) or ``"world"`` (as
        standard, with the coordinates of ``setworldcoordinates``).

        :param mode: the mode, ``None`` to return it.
        :return: the mode, if ``mode`` is ``None``.
        """
        if mode is None:
            return self._mode
        mode = mode.lower()
        if mode not in ["standard", "logo", "world"]:
            raise TurtleGraphicsError("No turtle-graphics-mode %s" % mode)
        self._mode = mode
        if mode in ["standard", "logo"]:
            self._world = None
            self._set_scale()
        self.reset()

    def reset(self):
        """Reset all the turtles (their drawings are deleted)."""
        for t in self._turtles:
            t._setmode(self._mode)
            t.reset()

    resetscreen = reset

    def clear(self):
        """
        Delete all the drawings and all the turtles, restore the white
        background and the color mode.
        """
        frame = self._next_frame()
        for t in self._turtles:
            frame.set(t._outer, "opacity", 0)
            if isinstance(frame, _StaticFrame):
                self._turtle_svgs.remove(t._outer)
        for layer in (self.background_canvas, self.canvas):
            frame.disappear(layer)
        self._new_layers()
        self._turtles = []
        self._generation += 1
        self._colormode = _CFG["colormode"]
        Turtle._pen = None

    clearscreen = clear

    def _new_scene(self):
        """Start a new scene: no turtles, transparent background."""
        self._close_frame()
        self._turtles = []
        self._turtle_svgs = []
        self._generation += 1
        self._stamp_count = 0
        self.frame_index = 0
        self._frame = None
        self._animated = False
        self._instant_id = None
        self._scene_finished = False
        self._bgcolor = "white"
        self._bgpicname = "nopic"
        self._colormode = _CFG["colormode"]
        self._delayvalue = _CFG["delay"]
        self._title = None
        self.width = _CFG["canvwidth"]
        self.height = _CFG["canvheight"]
        self._mode = _CFG["mode"].lower()
        self._world = None
        self._set_scale()
        self._setup_canvas()

    def restart(self):
        """Restore the default configuration and start a new scene."""
        _CFG.update(_default_cfg())
        self._new_scene()
        Turtle._pen = None

    def _set_scale(self):
        """Set the conversion of coordinates (``_to_svg``)."""
        if self._world is None:
            self._x0 = self._y0 = 0
            self._xscale = self._yscale = 1
        else:
            llx, lly, urx, ury = self._world
            self._x0 = (llx + urx) / 2
            self._y0 = (lly + ury) / 2
            self._xscale = self.width / (urx - llx)
            self._yscale = self.height / (ury - lly)

    def _setup_canvas(self):
        """
        Create the SVG scene and its layers (timing, background, drawings,
        turtles).
        """
        self.svg_id = str(uuid4()).replace("-", "")
        self.svg_scene = SVG.svg(
            width=self.width,
            height=self.height,
            preserveAspectRatio="xMidYMid meet",
            viewBox=self._viewbox(),
        )
        self._title_element = None
        # animations used for timing purpose, the first starts the scene
        # (if not animated, it is removed in end_scene())
        self._timing = SVG.g()
        appendTo(self.svg_scene, self._timing)
        self._timing_anim("0s", self.animation_frame_id(self.frame_index))

        # Unlike html elements, svg elements have no concept of a z-index: each
        # new element is drawn on top of each other.
        # Having separate canvas keeps the ordering
        self.turtle_canvas = SVG.g()
        appendTo(self.svg_scene, self.turtle_canvas)
        self._new_layers()

    def _new_layers(self):
        """Create empty background and drawing layers (under the turtles)."""
        self.background_canvas = SVG.g()
        self.canvas = SVG.g()
        self.svg_scene.insertBefore(self.background_canvas, self.turtle_canvas)
        self.svg_scene.insertBefore(self.canvas, self.turtle_canvas)
        self._bg_rect = None
        self._bgpic = None
        self._bgcolor = "white"
        self._bgpicname = "nopic"

    def _viewbox(self):
        """
        The SVG scene's view box (centered on the origin).

        :return: its value.
        """
        w, h = self.width, self.height
        return f"{_round(-w / 2)} {_round(-h / 2)} {w} {h}"

    def setworldcoordinates(self, llx, lly, urx, ury):
        """
        Set up a user defined coordinate system (the ``"world"`` mode,
        resetting the turtles if not already in this mode). Angles may appear
        distorted.

        :param llx: x-coordinate of the lower left corner.
        :param lly: y-coordinate of the lower left corner.
        :param urx: x-coordinate of the upper right corner.
        :param ury: y-coordinate of the upper right corner.
        """
        if urx == llx or ury == lly:
            raise TurtleGraphicsError("Empty world coordinates.")
        if self.mode() != "world":
            self.mode("world")
        self._world = (llx, lly, urx, ury)
        self._rescale()

    def _rescale(self):
        """Apply a change of coordinates to the turtles."""
        self._set_scale()
        for t in self._turtles:
            t._rescale()

    def screensize(self, canvwidth=None, canvheight=None, bg=None):
        """
        Set or return the size of the drawing (in pixels).

        :param canvwidth: the width, ``None`` to keep it.
        :param canvheight: the height, ``None`` to keep it.
        :param bg: the background color, if any.
        :return: (width, height), without argument.
        """
        if canvwidth is canvheight is bg is None:
            return self.width, self.height
        if canvwidth is not None:
            self.width = int(canvwidth)
        if canvheight is not None:
            self.height = int(canvheight)
        self.svg_scene.setAttribute("width", self.width)
        self.svg_scene.setAttribute("height", self.height)
        self.svg_scene.setAttribute("viewBox", self._viewbox())
        if self._world is not None:
            self._rescale()
        if bg is not None:
            self.bgcolor(bg)

    def setup(self, width=None, height=None, startx=None, starty=None):
        """
        Set the size of the drawing, as ``screensize``.

        :param width: the width in pixels (an integer: fractions of the screen
            are ignored).
        :param height: the height in pixels (an integer: fractions of the
            screen are ignored).
        :param startx: ignored.
        :param starty: ignored.
        """
        if not isinstance(width, int) or width <= 0:
            width = None
        if not isinstance(height, int) or height <= 0:
            height = None
        if width is not None or height is not None:
            self.screensize(width, height)

    def window_width(self):
        """Return the width of the drawing."""
        return self.width

    def window_height(self):
        """Return the height of the drawing."""
        return self.height

    def title(self, titlestring):
        """
        Set the drawing's title (displayed when the mouse is over it).

        :param titlestring: the title.
        """
        self._title = str(titlestring)
        if self._title_element is None:
            self._title_element = SVG.title(self._title)
            children = self.svg_scene._children
            self.svg_scene.insertBefore(self._title_element, children[0])
        else:
            self._title_element._children[0]._value = self._title

    def end_scene(self):
        """
        End the creation of a "scene".

        :return: the SVG scene.
        """
        self._close_frame()
        # removing animation used for timing purpose
        if not self._animated and self._timing.parentNode is not None:
            self.svg_scene.removeChild(self._timing)
        if not self._scene_finished:
            for t in self._turtle_svgs:
                appendTo(self.turtle_canvas, t)
            self._scene_finished = True
        self._old_svg_scene = self.svg_scene
        return self.svg_scene

    def show_scene(self):
        """Ends the creation of a "scene" and has it displayed"""
        return self.end_scene()

    def mainloop(self):
        """End the drawing and display it (to call at the end of the program)."""
        self.show_scene()

    done = mainloop

    def exitonclick(self):
        """End the drawing and display it, as ``done``."""
        self.show_scene()

    def bye(self):
        """Do nothing (there is no window to close)."""
        pass

    def turtles(self):
        """Return the list of turtles on the screen."""
        return self._turtles

    def register_shape(self, name, shape=None):
        """
        Add a turtle shape.

        :param name: the shape's name, or a GIF or PNG file name if ``shape``
            is ``None``.
        :param shape: a ``Shape`` or a tuple of points (heading towards
            positive y, x on the turtle's right).
        """
        if shape is None:
            if not name.lower().endswith((".gif", ".png")):
                raise TurtleGraphicsError(
                    "Bad arguments for register_shape.\nUse  help(register_shape)"
                )
            shape = Shape("image", name)
        elif isinstance(shape, (tuple, list)):
            shape = Shape("polygon", shape)
        self._shapes[name] = shape

    addshape = register_shape

    def getshapes(self):
        """Return the sorted list of the shapes' names."""
        return sorted(self._shapes.keys())

    def _shape_element(self, name):
        """
        Create the SVG element of a shape.

        :param name: the shape's name.
        :return: the element.
        """
        shape = self._shapes[name]
        if hasattr(shape, "_svg"):
            return shape._svg()
        if shape._type == "polygon":
            # the x axis is mirrored in the turtle's SVG frame
            return create_polygon([(-x, y) for x, y in shape._data])
        if shape._type == "compound":
            group = SVG.g()
            for poly, fill, outline in shape._data:
                polygon = create_polygon([(-x, y) for x, y in poly])
                polygon.setAttribute("fill", self._css(self._colorstr((fill,))))
                polygon.setAttribute("stroke", self._css(self._colorstr((outline,))))
                appendTo(group, polygon)
            return group
        # image
        if shape._data is None:
            return SVG.g()
        url, width, height = shape._data
        return SVG.image(
            href=url, x=-width / 2, y=-height / 2, width=width, height=height
        )

    def textinput(self, title, prompt):
        """
        Ask for a string (with ``input``).

        :param title: the question's title.
        :param prompt: the question.
        :return: the answer, ``None`` if empty.
        """
        answer = input(f"{title} - {prompt} " if title else f"{prompt} ")
        return answer if answer else None

    def numinput(self, title, prompt, default=None, minval=None, maxval=None):
        """
        Ask for a number (with ``input``), until it is valid.

        :param title: the question's title.
        :param prompt: the question.
        :param default: the answer if empty.
        :param minval: the minimum, if any.
        :param maxval: the maximum, if any.
        :return: the number (a float).
        """
        while True:
            answer = self.textinput(title, prompt)
            if answer is None:
                return default
            try:
                value = float(answer)
            except ValueError:
                print("Not a valid number:", answer)
                continue
            if minval is not None and value < minval:
                print("The minimum value is", minval)
            elif maxval is not None and value > maxval:
                print("The maximum value is", maxval)
            else:
                return value

    def getcanvas(self, *args, **kwargs):
        """
        Not implemented: print a warning.

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Screen.getcanvas")

    def listen(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Screen.listen")

    def onkey(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Screen.onkey")

    onkeyrelease = onkey

    def onkeypress(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Screen.onkeypress")

    def onscreenclick(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Screen.onscreenclick")

    onclick = onscreenclick

    def ontimer(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Screen.ontimer")


def _undoable(method):
    """
    Decorator of the turtle's methods recorded in its undo buffer (the
    methods they call are part of the same entry).

    :param method: the method.
    :return: the decorated method.
    """

    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        if self._undo_depth or self._undobuffer is None:
            return method(self, *args, **kwargs)
        state = self._state()
        nitems = len(self._items)
        generation = self._generation
        self._undo_depth += 1
        try:
            result = method(self, *args, **kwargs)
        finally:
            self._undo_depth -= 1
        if self._undobuffer is None or generation != self._generation:
            return result
        items = self._items[nitems:]
        if items or state != self._state():
            self._undobuffer.append((state, items))
            if len(self._undobuffer) > self._undobuffersize:
                del self._undobuffer[0]
        return result

    return wrapper


class TNavigator:
    """Navigation part of the Turtle.
    Implements methods for turtle movement.
    """

    START_ORIENTATION = {"standard": 0.0, "world": 0.0, "logo": 90.0}
    DEFAULT_MODE = "standard"
    DEFAULT_ANGLEOFFSET = 0
    DEFAULT_ANGLEORIENT = 1

    def __init__(self, mode=DEFAULT_MODE):
        """:param mode: the mode (``"standard"``, ``"logo"`` or ``"world"``)."""
        self._angleOffset = self.DEFAULT_ANGLEOFFSET
        self._angleOrient = self.DEFAULT_ANGLEORIENT
        self._mode = mode
        self.degrees()
        self._setmode(mode)
        TNavigator.reset(self)

    def reset(self):
        """reset turtle navigation to its initial values

        The derived class, which will call it directly and add its own
        """
        self._x = 0.0
        self._y = 0.0
        # heading in degrees, counterclockwise from east
        self._angle = self.START_ORIENTATION[self._mode]

    def _setmode(self, mode=None):
        """
        Set or return the turtle's mode.

        :param mode: ``"standard"``, ``"world"`` or ``"logo"``, ``None`` to
            return it.
        :return: the mode, if ``mode`` is ``None``.
        """
        if mode is None:
            return self._mode
        if mode not in ["standard", "logo", "world"]:
            return
        self._mode = mode
        if mode in ["standard", "world"]:
            self._angleOffset = 0
            self._angleOrient = 1
        else:  # mode == "logo":
            self._angleOffset = self._fullcircle / 4.0
            self._angleOrient = -1

    def _setDegreesPerAU(self, fullcircle):
        """
        Set the angle unit (for ``degrees`` and ``radians``).

        :param fullcircle: the number of units in a full circle.
        """
        self._fullcircle = fullcircle
        self._degreesPerAU = 360 / fullcircle
        if self._mode == "logo":
            self._angleOffset = fullcircle / 4.0
        else:
            self._angleOffset = 0

    def degrees(self, fullcircle=360.0):
        """
        Set the angle unit to degrees, or another one.

        :param fullcircle: the number of units in a full circle.
        """
        self._setDegreesPerAU(fullcircle)

    def radians(self):
        """Set the angle measurement units to radians."""
        self._setDegreesPerAU(math.tau)

    def _rotate(self, angle):
        """
        Turn the turtle counterclockwise (implemented by ``Turtle``).

        :param angle: the angle (in the angle unit).
        """
        pass

    def _goto(self, x, y):
        """
        Move the turtle (implemented by ``Turtle``).

        :param x: the first coordinate.
        :param y: the second coordinate.
        """
        pass  # implemented by derived class

    @_undoable
    def forward(self, distance):
        """
        Move the turtle forward (backward if ``distance`` is negative).

        :param distance: the distance.
        """
        a = math.radians(self._angle)
        self._goto(self._x + distance * cos(a), self._y + distance * sin(a))

    fd = forward

    @_undoable
    def back(self, distance):
        """
        Move the turtle backward (forward if ``distance`` is negative).

        :param distance: the distance.
        """
        self.forward(-distance)

    backward = back
    bk = back

    @_undoable
    def right(self, angle):
        """
        Turn the turtle right (left if ``angle`` is negative).

        :param angle: the angle (in the angle unit).
        """
        self._rotate(-angle)

    rt = right

    @_undoable
    def left(self, angle):
        """
        Turn the turtle left (right if ``angle`` is negative).

        :param angle: the angle (in the angle unit).
        """
        self._rotate(angle)

    lt = left

    def pos(self):
        """Return the turtle's current location (x,y), as a Vec2D vector."""
        return Vec2D(self._x, self._y)

    position = pos

    def xcor(self):
        """Return the turtle's x coordinate."""
        return self._x

    def ycor(self):
        """Return the turtle's y coordinate"""
        return self._y

    @_undoable
    def goto(self, x, y=None):
        """
        Move the turtle to a position.

        :param x: the first coordinate, or a pair of coordinates.
        :param y: the second coordinate.
        """
        x, y = _point(x, y)
        self._goto(x, y)

    setpos = goto
    setposition = goto

    @_undoable
    def teleport(self, x=None, y=None, *, fill_gap=False):
        """
        Move the turtle instantly without drawing.

        :param x: the first coordinate, ``None`` to keep it.
        :param y: the second coordinate, ``None`` to keep it.
        :param fill_gap: whether a shape being filled includes the gap
            (otherwise, a new shape starts).
        """
        x = self._x if x is None else x
        y = self._y if y is None else y
        filling = self.filling()
        if filling and not fill_gap:
            self.end_fill()
        drawing, speed = self._drawing, self._speed
        self._drawing, self._speed = False, 0
        self._goto(x, y)
        self._drawing, self._speed = drawing, speed
        if filling and not fill_gap:
            self.begin_fill()

    @_undoable
    def home(self):
        """Move turtle to the origin - coordinates (0,0), facing in the
        default orientation
        """
        self.goto(0, 0)
        self.setheading(0)

    @_undoable
    def setx(self, x):
        """
        Set the turtle's first coordinate.

        :param x: the coordinate.
        """
        self._goto(x, self._y)

    @_undoable
    def sety(self, y):
        """
        Set the turtle's second coordinate.

        :param y: the coordinate.
        """
        self._goto(self._x, y)

    def distance(self, x, y=None):
        """
        Distance from the turtle to a point.

        :param x: the point's first coordinate, a pair of coordinates or a
            turtle.
        :param y: the point's second coordinate.
        :return: the distance.
        """
        return abs(_point(x, y) - self.pos())

    def towards(self, x, y=None):
        """
        Angle of the line from the turtle to a point.

        :param x: the point's first coordinate, a pair of coordinates or a
            turtle.
        :param y: the point's second coordinate.
        :return: the angle (in the angle unit).
        """
        x, y = _point(x, y) - self.pos()
        result = round(math.degrees(math.atan2(y, x)), 10) % 360.0
        result /= self._degreesPerAU
        return (self._angleOffset + self._angleOrient * result) % self._fullcircle

    def heading(self):
        """Return the turtle's current heading."""
        result = round(self._angle, 10) % 360.0
        result /= self._degreesPerAU
        return (self._angleOffset + self._angleOrient * result) % self._fullcircle

    @_undoable
    def setheading(self, to_angle):
        """
        Set the turtle's orientation (turning the shortest way).

        :param to_angle: the angle (in the angle unit; in logo mode, 0 is north
            and angles are clockwise).
        """
        angle = (to_angle - self.heading()) * self._angleOrient
        full = self._fullcircle
        angle = (angle + full / 2.0) % full - full / 2.0
        self._rotate(angle)

    seth = setheading

    @_undoable
    def circle(self, radius, extent=None, steps=None):
        """
        Draw a circle (or an arc) approximated by a regular polygon. Its center
        is ``radius`` units left of the turtle; the arc is drawn
        counterclockwise if ``radius`` is positive, clockwise otherwise (and
        backwards if ``extent`` is negative). The turtle's orientation changes
        by ``extent``.

        :param radius: the circle's radius.
        :param extent: the arc's angle, the full circle if ``None``.
        :param steps: the number of sides of the polygon, computed from the
            radius if ``None`` (to draw regular polygons).
        """
        speed = self.speed()
        if extent is None:
            extent = self._fullcircle
        if steps is None:
            frac = abs(extent) / self._fullcircle
            steps = 1 + int(min(11 + abs(radius) / 6.0, 59.0) * frac)
        w = 1.0 * extent / steps
        w2 = 0.5 * w
        l = 2.0 * radius * math.sin(math.radians(w2) * self._degreesPerAU)
        if radius < 0:
            l, w, w2 = -l, -w, -w2
        self.speed(0)
        self._rotate(w2)
        for i in range(steps):
            self.speed(speed)
            self.forward(l)
            self.speed(0)
            self._rotate(w)
        self._rotate(-w2)
        self.speed(speed)


class TPen:
    """Drawing part of the Turtle."""

    def __init__(self, resizemode=None):
        """:param resizemode: the resize mode (from the configuration if ``None``)."""
        self.screen = Screen()
        self._resizemode = resizemode or _CFG["resizemode"]
        TPen._reset(self)

    def _reset(self, pencolor=None, fillcolor=None):
        """
        Restore the pen's default values.

        :param pencolor: the pen color (from the configuration if ``None``).
        :param fillcolor: the fill color (from the configuration if ``None``).
        """
        self._pensize = 1
        self._shown = True
        self._drawing = True
        self._pencolor = pencolor or _CFG["pencolor"]
        self._fillcolor = fillcolor or _CFG["fillcolor"]
        self._speed = 3
        self._stretchfactor = (1.0, 1.0)
        self._shearfactor = 0.0
        self._tilt = 0.0
        self._shapetrafo = (1.0, 0.0, 0.0, 1.0)
        self._outlinewidth = 1

    def resizemode(self, rmode=None):
        """
        Set or return how the shape is resized: ``"auto"`` (with the pen's
        width), ``"user"`` (with ``shapesize``) or ``"noresize"``.

        :param rmode: the mode, ``None`` to return it.
        :return: the mode, if ``rmode`` is ``None``.
        """
        if rmode is None:
            return self._resizemode
        rmode = rmode.lower()
        if rmode in ["auto", "user", "noresize"]:
            self.pen(resizemode=rmode)

    def pensize(self, width=None):
        """
        Set or return the line's width.

        :param width: the width, ``None`` to return it.
        :return: the width, if ``width`` is ``None``.
        """
        if width is None:
            return self._pensize
        self.pen(pensize=width)

    width = pensize

    def pendown(self):
        """Pull the pen down -- drawing when moving."""
        if self._drawing:
            return
        self.pen(pendown=True)

    pd = pendown
    down = pendown

    def penup(self):
        """Pull the pen up -- no drawing when moving."""
        if not self._drawing:
            return
        self.pen(pendown=False)

    pu = penup
    up = penup

    def isdown(self):
        """Return True if pen is down, False if it's up."""
        return self._drawing

    def speed(self, speed=None):
        """
        Set or return the turtle's speed, an integer from 0 to 10 (0 being no
        animation: the turtle jumps and turns instantly). A number greater than
        10 or smaller than 0.5 sets it to 0. Speed strings are ``"fastest"``
        (0), ``"fast"`` (10), ``"normal"`` (6), ``"slow"`` (3) and ``"slowest"``
        (1).

        :param speed: the speed, ``None`` to return it.
        :return: the speed, if ``speed`` is ``None``.
        """
        speeds = {"fastest": 0, "fast": 10, "normal": 6, "slow": 3, "slowest": 1}
        if speed is None:
            return self._speed
        if speed in speeds:
            speed = speeds[speed]
        elif 0.5 < speed < 10.5:
            speed = int(round(speed))
        else:
            speed = 0
        self.pen(speed=speed)

    def color(self, *args):
        """
        Set or return the pen and fill colors. A color is a string in any
        format of the browser (name, ``"#rrggbb"``, ``"rgb(...)"``...) or a
        tuple ``(r, g, b)`` of numbers up to ``colormode()``.

        :param ``*args``: none to return the colors, one color for both, two
            colors (pen, fill), a pair of colors (pen, fill) or three numbers
            ``r, g, b`` for both.
        :return: (pen color, fill color), without argument.
        """
        if args:
            l = len(args)
            if l == 1:
                pencolor = fillcolor = args[0]
                if (
                    isinstance(args[0], (tuple, list))
                    and len(args[0]) == 2
                    and all(isinstance(c, (str, tuple, list)) for c in args[0])
                ):
                    pencolor, fillcolor = args[0]
            elif l == 2:
                pencolor, fillcolor = args
            elif l == 3:
                pencolor = fillcolor = args
            else:
                raise TurtleGraphicsError("bad color arguments: %s" % str(args))
            pencolor = self.screen._colorstr((pencolor,))
            fillcolor = self.screen._colorstr((fillcolor,))
            self.pen(pencolor=pencolor, fillcolor=fillcolor)
        else:
            return self.screen._color(self._pencolor), self.screen._color(
                self._fillcolor
            )

    def pencolor(self, *args):
        """
        Set or return the pen color: a string in any format of the browser or
        a tuple ``(r, g, b)`` of numbers up to ``colormode()``.

        :param ``*args``: the color (or three numbers ``r, g, b``), none to
            return it.
        :return: the pen color, without argument.
        """
        if args:
            color = self.screen._colorstr(args)
            if color == self._pencolor:
                return
            self.pen(pencolor=color)
        else:
            return self.screen._color(self._pencolor)

    def fillcolor(self, *args):
        """
        Set or return the fill color: a string in any format of the browser or
        a tuple ``(r, g, b)`` of numbers up to ``colormode()``.

        :param ``*args``: the color (or three numbers ``r, g, b``), none to
            return it.
        :return: the fill color, without argument.
        """
        if args:
            color = self.screen._colorstr(args)
            if color == self._fillcolor:
                return
            self.pen(fillcolor=color)
        else:
            return self.screen._color(self._fillcolor)

    def showturtle(self):
        """Makes the turtle visible."""
        self.pen(shown=True)

    st = showturtle

    def hideturtle(self):
        """Makes the turtle invisible."""
        self.pen(shown=False)

    ht = hideturtle

    def isvisible(self):
        """Return True if the Turtle is shown, False if it's hidden."""
        return self._shown

    def pen(self, pen=None, **pendict):
        """
        Set or return the pen's attributes: ``"shown"``, ``"pendown"``
        (booleans), ``"pencolor"``, ``"fillcolor"`` (colors), ``"pensize"``
        (positive number), ``"speed"`` (from 0 to 10), ``"resizemode"``,
        ``"stretchfactor"`` (pair of numbers), ``"shearfactor"``,
        ``"outline"`` (numbers) and ``"tilt"`` (angle in radians, clockwise).

        :param pen: a dict of attributes.
        :param ``**pendict``: attributes as keyword arguments.
        :return: the dict of the attributes, without argument.
        """
        _pd = {
            "shown": self._shown,
            "pendown": self._drawing,
            "pencolor": self._pencolor,
            "fillcolor": self._fillcolor,
            "pensize": self._pensize,
            "speed": self._speed,
            "resizemode": self._resizemode,
            "stretchfactor": self._stretchfactor,
            "shearfactor": self._shearfactor,
            "outline": self._outlinewidth,
            "tilt": self._tilt,
        }

        if not (pen or pendict):
            return _pd

        if isinstance(pen, dict):
            p = dict(pen)
        else:
            p = {}
        p.update(pendict)
        for key in p:
            if key not in _pd:
                raise TurtleGraphicsError("unknown pen attribute: %s" % key)

        if "pendown" in p:
            self._drawing = bool(p["pendown"])
        if "pencolor" in p:
            self._pencolor = self.screen._colorstr((p["pencolor"],))
        if "pensize" in p:
            self._pensize = p["pensize"]
        if "fillcolor" in p:
            self._fillcolor = self.screen._colorstr((p["fillcolor"],))
        if "speed" in p:
            self._speed = p["speed"]
        if "resizemode" in p:
            self._resizemode = p["resizemode"]
        if "stretchfactor" in p:
            sf = p["stretchfactor"]
            if isinstance(sf, (int, float)):
                sf = (sf, sf)
            self._stretchfactor = tuple(sf)
        if "shearfactor" in p:
            self._shearfactor = p["shearfactor"]
        if "outline" in p:
            self._outlinewidth = p["outline"]
        if "shown" in p:
            self._shown = bool(p["shown"])
        if "tilt" in p:
            delta = math.degrees(p["tilt"] - self._tilt)
            self._tilt = p["tilt"]
            self._rot = _round(self._rot + self._mirror() * delta)
        if "stretchfactor" in p or "tilt" in p or "shearfactor" in p:
            scx, scy = self._stretchfactor
            shf = self._shearfactor
            sa, ca = math.sin(self._tilt), math.cos(self._tilt)
            self._shapetrafo = (
                scx * ca,
                scy * (shf * ca + sa),
                -scx * sa,
                scy * (ca - shf * sa),
            )
        self._sync()


# No RawTurtle/RawPen for this version, unlike CPython's; only Turtle/Pen
class Turtle(TPen, TNavigator):
    """Animation part of the Turtle.
    Puts Turtle upon a TurtleScreen and provides tools for
    its animation.
    """

    _pen = None
    screen = None

    def __init__(self, shape=None, undobuffersize=None, visible=None):
        """
        Create a turtle on the screen.

        :param shape: the shape's name (``"turtle"``, ``"arrow"``,
            ``"classic"``, ``"triangle"``, ``"square"``, ``"circle"`` or a
            registered one), from the configuration if ``None``.
        :param undobuffersize: the number of actions that can be undone, from
            the configuration if ``None``.
        :param visible: whether the turtle is shown, from the configuration if
            ``None``.
        """
        self.screen = Screen()
        self._undo_depth = 0
        self._undobuffer = None
        self._items = []
        self._rot = 0
        TPen.__init__(self)
        TNavigator.__init__(self, self.screen.mode())
        if shape is None:
            shape = _CFG["shape"]
        if shape not in self.screen._shapes:
            raise TurtleGraphicsError("There is no shape named %s" % shape)
        self._shape = shape
        if visible is None:
            visible = _CFG["visible"]
        self._shown = bool(visible)
        if undobuffersize is None:
            undobuffersize = _CFG["undobuffersize"]
        self._undobuffersize = undobuffersize
        self._poly = None
        self._creatingPoly = False
        self._rot = self._rot_towards(0)
        self._attach()

    @property
    def name(self):
        """The shape's name."""
        return self._shape

    # Visual part: the turtle's SVG elements follow its state through
    # _sync(), which adds the animations of the changes (or applies them if
    # there is no animation).

    def _attach(self):
        """Create the turtle's SVG elements in the current scene."""
        screen = self.screen
        self._generation = screen._generation
        self._items = []
        self._stamps = {}
        self._fillpath = self._fillitem = None
        if self._undobuffersize:
            self._undobuffer = []
        else:
            self._undobuffer = None
        self._outer = SVG.g()
        self._heading_g = SVG.g()
        self._skew_g = SVG.g()
        self._scale_g = SVG.g()
        appendTo(self._outer, self._heading_g)
        appendTo(self._heading_g, self._skew_g)
        appendTo(self._skew_g, self._scale_g)
        self._shape_elements = {}
        # initial state set without animation
        frame = _StaticFrame()
        self._vis = {}
        self._sync(frame=frame)
        if not screen._static():
            # will appear with an animation
            self._outer.setAttribute("opacity", 0)
            self._vis["opacity"] = 0
        screen._turtles.append(self)
        screen._turtle_svgs.append(self._outer)
        self._sync()

    def _ensure_attached(self):
        """Recreate the turtle's SVG elements after a new scene."""
        if self._generation != self.screen._generation:
            self._attach()

    def _frame(self):
        """
        Start a new drawing action.

        :return: the frame.
        """
        self._ensure_attached()
        return self.screen._next_frame()

    def _mirror(self):
        """
        Whether the world coordinates are mirrored on the screen.

        :return: 1 if not, -1 if they are.
        """
        return 1 if self.screen._xscale * self.screen._yscale > 0 else -1

    def _rot_towards(self, approx):
        """
        SVG rotation of the turtle's shape for its heading and tilt.

        :param approx: approximation of the rotation, giving the number of
            full turns.
        :return: the rotation (in degrees).
        """
        target = (
            self.screen._screen_angle(self._angle)
            - 90
            + self._mirror() * math.degrees(self._tilt)
        )
        return _round(approx + ((target - approx + 180) % 360 - 180))

    def _shape_params(self):
        """
        The shape's transformation, depending on the resize mode.

        :return: shear (degrees of SVG skewX), stretch factors and outline
            width.
        """
        if self._resizemode == "user":
            shear = -math.degrees(math.atan(self._shearfactor))
            return _round(shear), self._stretchfactor, self._outlinewidth
        if self._resizemode == "auto":
            l = max(1, self._pensize / 5.0)
            return 0, (l, l), self._pensize
        return 0, (1, 1), 1

    def _desired(self):
        """
        The turtle's visual state.

        :return: the values by name.
        """
        shear, (scx, scy), outline = self._shape_params()
        css = self.screen._css
        return {
            "opacity": 1 if self._shown else 0,
            "stroke": css(self._pencolor),
            "fill": css(self._fillcolor),
            "stroke-width": outline,
            "shape": self._shape,
            "translate": "%s %s" % self.screen._to_svg(self._x, self._y),
            "rotate": self._rot,
            "skewX": shear,
            "scale": f"{_round(scx)} {_round(scy)}",
        }

    def _shape_element(self, name):
        """
        SVG element of one of the turtle's shapes (created if needed, hidden).

        :param name: the shape's name.
        :return: the element.
        """
        if name not in self._shape_elements:
            element = self.screen._shape_element(name)
            element.setAttribute("display", "none")
            if self.screen._shapes[name]._type == "image":
                # images do not turn
                self._outer.insertBefore(element, self._heading_g)
            else:
                appendTo(self._scale_g, element)
            self._shape_elements[name] = element
        return self._shape_elements[name]

    def _sync(self, move=0, turn=0, frame=None):
        """
        Update the turtle's SVG elements to its state (the position and
        heading of a hidden turtle are updated when it is shown).

        :param move: the duration of the move (in seconds).
        :param turn: the duration of the rotation (in seconds).
        :param frame: the drawing action, a new one if needed when ``None``.
        """
        if frame is None:
            self._ensure_attached()
        want = self._desired()
        vis = self._vis
        changes = [k for k, v in want.items() if vis.get(k) != v]
        if not self._shown:
            changes = [k for k in changes if k not in ("translate", "rotate")]
        if not changes:
            return
        if frame is None:
            frame = self.screen._next_frame()
        for key in changes:
            value = want[key]
            if key not in vis and (key, value) in (("skewX", 0), ("scale", "1 1")):
                # identity transforms at creation
                pass
            elif key == "shape":
                if key in vis:
                    frame.set(self._shape_element(vis[key]), "display", "none")
                frame.set(self._shape_element(value), "display", "inline")
            elif key in ("opacity", "stroke", "fill", "stroke-width"):
                frame.set(self._outer, key, value)
            else:
                element, seconds = {
                    "translate": (self._outer, move),
                    "rotate": (self._heading_g, turn),
                    "skewX": (self._skew_g, 0),
                    "scale": (self._scale_g, 0),
                }[key]
                old = vis.get(key, value)
                frame.transform(element, key, old, value, seconds)
            vis[key] = value

    def _move_seconds(self, distance):
        """
        Duration of a move with the turtle's speed.

        :param distance: the distance (in pixels).
        :return: the duration (in seconds).
        """
        # The speed scale does not correspond exactly to the CPython one...
        if self._speed == 0:
            return 0
        if self._speed == 1:
            return 0.02 * distance
        return 0.02 * distance / self._speed**1.2

    def _turn_seconds(self, angle):
        """
        Duration of a rotation with the turtle's speed.

        :param angle: the angle (in degrees).
        :return: the duration (in seconds).
        """
        if self._speed == 0:
            return 0
        return abs(angle) / (self._speed * 360)

    def _state(self):
        """
        The turtle's state, as recorded in the undo buffer.

        :return: the values by attribute's name.
        """
        state = {k: v for k, v in vars(self).items() if k in self._STATE}
        for k in ("_fillpath", "_poly"):
            if state[k] is not None:
                state[k] = list(state[k])
        return state

    _STATE = {
        "_x",
        "_y",
        "_angle",
        "_rot",
        "_pensize",
        "_shown",
        "_drawing",
        "_pencolor",
        "_fillcolor",
        "_speed",
        "_resizemode",
        "_stretchfactor",
        "_shearfactor",
        "_tilt",
        "_shapetrafo",
        "_outlinewidth",
        "_shape",
        "_fillpath",
        "_fillitem",
        "_poly",
        "_creatingPoly",
    }

    def reset(self):
        """
        Delete the turtle's drawings and restore its default values: home,
        heading, pen and colors.
        """
        self._clear()
        TNavigator.reset(self)
        TPen._reset(self)
        self._rot = self._rot_towards(self._rot)
        self._sync()

    def clear(self):
        """Delete the turtle's drawings (its state remains)."""
        self._clear()

    def _clear(self):
        """Delete the turtle's drawings and empty its undo buffer."""
        self._ensure_attached()
        if self._items:
            frame = self.screen._next_frame()
            for item in self._items:
                frame.disappear(item)
        self._items = []
        self._stamps = {}
        self._fillpath = self._fillitem = None
        if self._undobuffer is not None:
            self._undobuffer = []

    def _rescale(self):
        """Apply a change of coordinates to the turtle's shape."""
        self._rot = self._rot_towards(self._rot)
        self._sync()

    @_undoable
    def shape(self, name=None):
        """
        Set or return the turtle's shape.

        :param name: the shape's name (see ``getshapes()``), ``None`` to
            return it.
        :return: the shape's name, if ``name`` is ``None``.
        """
        if name is None:
            return self._shape
        if name not in self.screen._shapes:
            raise TurtleGraphicsError("There is no shape named %s" % name)
        self._shape = name
        self._sync()

    @_undoable
    def shapesize(self, stretch_wid=None, stretch_len=None, outline=None):
        """
        Set or return the shape's stretch factors and outline width (setting
        the resize mode to ``"user"``).

        :param stretch_wid: the stretch factor perpendicular to the heading.
        :param stretch_len: the stretch factor along the heading (as
            ``stretch_wid`` if ``None``).
        :param outline: the outline's width.
        :return: (stretch_wid, stretch_len, outline), without argument.
        """
        if stretch_wid is stretch_len is outline is None:
            stretch_wid, stretch_len = self._stretchfactor
            return stretch_wid, stretch_len, self._outlinewidth
        if stretch_wid == 0 or stretch_len == 0:
            raise TurtleGraphicsError("stretch_wid/stretch_len must not be zero")
        if stretch_wid is not None:
            if stretch_len is None:
                stretchfactor = stretch_wid, stretch_wid
            else:
                stretchfactor = stretch_wid, stretch_len
        elif stretch_len is not None:
            stretchfactor = self._stretchfactor[0], stretch_len
        else:
            stretchfactor = self._stretchfactor
        if outline is None:
            outline = self._outlinewidth
        self.pen(resizemode="user", stretchfactor=stretchfactor, outline=outline)

    turtlesize = shapesize

    @_undoable
    def shearfactor(self, shear=None):
        """
        Set or return the shape's shear factor (setting the resize mode to
        ``"user"``).

        :param shear: the tangent of the shear angle, ``None`` to return it.
        :return: the shear factor, if ``shear`` is ``None``.
        """
        if shear is None:
            return self._shearfactor
        self.pen(resizemode="user", shearfactor=shear)

    @_undoable
    def tiltangle(self, angle=None):
        """
        Set or return the shape's tilt, relative to the heading (setting the
        resize mode to ``"user"``).

        :param angle: the tilt (in the angle unit), ``None`` to return it.
        :return: the tilt, if ``angle`` is ``None``.
        """
        if angle is None:
            tilt = -math.degrees(self._tilt) * self._angleOrient
            return (tilt / self._degreesPerAU) % self._fullcircle
        tilt = -angle * self._degreesPerAU * self._angleOrient
        tilt = math.radians(tilt) % math.tau
        self.pen(resizemode="user", tilt=tilt)

    @_undoable
    def settiltangle(self, angle):
        """
        Set the shape's tilt (deprecated: use ``tiltangle``).

        :param angle: the tilt (in the angle unit).
        """
        self.tiltangle(angle)

    @_undoable
    def tilt(self, angle):
        """
        Turn the shape by an angle (its heading does not change).

        :param angle: the angle (in the angle unit).
        """
        self.tiltangle(angle + self.tiltangle())

    @_undoable
    def shapetransform(self, t11=None, t12=None, t21=None, t22=None):
        """
        Set or return the shape's transformation matrix (setting the resize
        mode to ``"user"``).

        :param t11: the first coefficient of the first row.
        :param t12: the second coefficient of the first row.
        :param t21: the first coefficient of the second row.
        :param t22: the second coefficient of the second row.
        :return: the matrix (t11, t12, t21, t22), without argument.
        """
        if t11 is t12 is t21 is t22 is None:
            return self._shapetrafo
        m11, m12, m21, m22 = self._shapetrafo
        if t11 is not None:
            m11 = t11
        if t12 is not None:
            m12 = t12
        if t21 is not None:
            m21 = t21
        if t22 is not None:
            m22 = t22
        if m11 * m22 - m12 * m21 == 0:
            raise TurtleGraphicsError(
                "Bad shape transform matrix: must not be singular"
            )
        alfa = math.atan2(-m21, m11) % math.tau
        sa, ca = math.sin(alfa), math.cos(alfa)
        a11, a12, a21, a22 = (
            ca * m11 - sa * m21,
            ca * m12 - sa * m22,
            sa * m11 + ca * m21,
            sa * m12 + ca * m22,
        )
        self.pen(
            resizemode="user",
            stretchfactor=(a11, a22),
            shearfactor=a12 / a22,
            tilt=alfa,
        )
        self._shapetrafo = (m11, m12, m21, m22)

    def get_shapepoly(self):
        """
        Return the current polygon of the shape (``None`` if it is not a
        polygon), transformed as displayed.
        """
        shape = self.screen._shapes[self._shape]
        if shape._type != "polygon":
            return None
        if self._resizemode == "user":
            t11, t12, t21, t22 = self._shapetrafo
        elif self._resizemode == "auto":
            l = max(1, self._pensize / 5.0)
            t11, t12, t21, t22 = l, 0, 0, l
        else:
            return shape._data
        return tuple((t11 * x + t12 * y, t21 * x + t22 * y) for (x, y) in shape._data)

    def clearstamp(self, stampid):
        """
        Delete a stamp.

        :param stampid: the stamp's id, returned by ``stamp``.
        """
        self._clearstamps([stampid])

    def clearstamps(self, n=None):
        """
        Delete the turtle's stamps.

        :param n: all if ``None``, the first ``n`` ones if positive, the last
            ``-n`` ones if negative.
        """
        ids = list(self._stamps)
        if n is not None:
            ids = ids[:n] if n >= 0 else ids[n:]
        self._clearstamps(ids)

    def _clearstamps(self, ids):
        """
        Delete stamps.

        :param ids: their ids.
        """
        ids = [i for i in ids if i in self._stamps]
        if not ids:
            return
        frame = self._frame()
        for i in ids:
            item = self._stamps.pop(i)
            frame.disappear(item)
            self._items.remove(item)

    def onclick(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Turtle.onclick")

    def ondrag(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Turtle.ondrag")

    def onrelease(self, *args, **kwargs):
        """
        Not implemented: print a warning (no events, the drawing is computed
        before being displayed).

        :param ``*args``: ignored.
        :param ``**kwargs``: ignored.
        """
        _warn_not_implemented("Turtle.onrelease")

    def undo(self):
        """Undo the last action of the turtle (repeatedly)."""
        if not self._undobuffer:
            return
        self._ensure_attached()
        state, items = self._undobuffer.pop()
        old = self.screen._to_svg(self._x, self._y)
        old_rot = self._rot
        frame = self.screen._next_frame()
        for item in items:
            if item in self._items:
                frame.disappear(item)
                self._items.remove(item)
            for i, stamp in list(self._stamps.items()):
                if stamp is item:
                    del self._stamps[i]
        for key, value in state.items():
            if isinstance(value, list):
                value = list(value)
            setattr(self, key, value)
        new = self.screen._to_svg(self._x, self._y)
        self._sync(
            move=self._move_seconds(math.dist(old, new)),
            turn=self._turn_seconds(self._rot - old_rot),
            frame=frame,
        )

    def setundobuffer(self, size):
        """
        Set the number of actions that can be undone.

        :param size: the number, ``None`` or 0 to disable undoing.
        """
        self._undobuffersize = size or 0
        self._undobuffer = [] if size else None

    def undobufferentries(self):
        """Return the number of actions that can be undone."""
        if self._undobuffer is None:
            return 0
        return len(self._undobuffer)

    def _goto(self, x, y):
        """
        Move the turtle, drawing a line if the pen is down. All the other
        movements use this one.

        :param x: the first coordinate.
        :param y: the second coordinate.
        """
        self._ensure_attached()
        screen = self.screen
        x0, y0 = screen._to_svg(self._x, self._y)
        x1, y1 = screen._to_svg(x, y)
        self._x, self._y = x + 0.0, y + 0.0
        if self._fillpath is not None:
            self._fillpath.append(self.pos())
        if self._creatingPoly:
            self._poly.append(self.pos())
        if not (self._drawing or self._shown):
            return
        seconds = self._move_seconds(math.hypot(x1 - x0, y1 - y0))
        frame = screen._next_frame()
        if self._drawing and (x0, y0) != (x1, y1):
            style = {
                "stroke": screen._css(self._pencolor),
                "stroke-width": self._pensize,
            }
            line = SVG.line(x1=x0, y1=y0, x2=x0, y2=y0, style=style)
            frame.animate(line, "x2", x0, x1, seconds)
            frame.animate(line, "y2", y0, y1, seconds)
            if self._pensize > 2:
                frame.set(line, "stroke-linecap", "round")
            appendTo(screen.canvas, line)
            self._items.append(line)
        self._sync(move=seconds, frame=frame)

    def _rotate(self, angle):
        """
        Turn the turtle counterclockwise.

        :param angle: the angle (in the angle unit).
        """
        self._ensure_attached()
        angle *= self._degreesPerAU
        self._angle += angle
        self._rot = self._rot_towards(self._rot - self._mirror() * angle)
        if self._shown:
            self._sync(turn=self._turn_seconds(angle))

    def filling(self):
        """Return fillstate (True if filling, False else)."""
        return self._fillpath is not None

    @_undoable
    def begin_fill(self):
        """Called just before drawing a shape to be filled."""
        self._ensure_attached()
        if not self.filling():
            # the filled shape is under the lines drawn while filling
            self._fillitem = SVG.g()
            appendTo(self.screen.canvas, self._fillitem)
            self._items.append(self._fillitem)
        self._fillpath = [self.pos()]

    @_undoable
    def end_fill(self):
        """Fill the shape drawn after the call begin_fill()."""
        if not self.filling():
            return
        self._ensure_attached()
        if len(self._fillpath) > 2 and self._fillitem is not None:
            frame = self.screen._next_frame()
            points = " ".join(
                ",".join(map(str, self.screen._to_svg(*p))) for p in self._fillpath
            )
            polygon = SVG.polygon(points=points, fill=self.screen._css(self._fillcolor))
            appendTo(self._fillitem, polygon)
            frame.appear(polygon)
            self._items.append(polygon)
        self._fillitem = self._fillpath = None

    @_undoable
    def dot(self, size=None, *color):
        """
        Draw a filled circle at the turtle's position (even if the pen is up).

        :param size: its diameter, from the pen's width if ``None`` (or the
            color if it is a string or a tuple).
        :param ``*color``: its color, the pen's one if none.
        """
        if not color:
            if isinstance(size, (str, tuple)):
                color = self.screen._colorstr((size,))
                size = self._pensize + max(self._pensize, 4)
            else:
                color = self._pencolor
                if not size:
                    size = self._pensize + max(self._pensize, 4)
        else:
            if size is None:
                size = self._pensize + max(self._pensize, 4)
            color = self.screen._colorstr(color)
        frame = self._frame()
        x, y = self.screen._to_svg(self._x, self._y)
        # `size` represents the diameter, svg needs the radius
        circle = SVG.circle(
            cx=x, cy=y, r=max(size, 1) / 2, fill=self.screen._css(color)
        )
        appendTo(self.screen.canvas, circle)
        frame.appear(circle)
        self._items.append(circle)

    @_undoable
    def write(
        self, arg, move=False, align="left", font=("Arial", 8, "normal"), color=None
    ):
        """
        Write a text at the turtle's position (its bottom).

        :param arg: what to write (converted to a string, lines separated by
            ``"\\n"``).
        :param move: whether the turtle moves to the end of the text (its
            width is approximated).
        :param align: ``"left"``, ``"center"`` or ``"right"``.
        :param font: (name, size, style), the style being ``"normal"`` or
            words among ``"bold"``, ``"italic"``, ``"underline"`` and
            ``"overstrike"``.
        :param color: its color, the pen's one if ``None``.
        """
        txt = str(arg)
        align = align.lower()
        if align == "centre":
            align = "center"
        font = tuple(font) + ("Arial", 8, "normal")[len(font) :]
        family, size, style = font[:3]
        color = self._pencolor if color is None else self.screen._colorstr((color,))
        frame = self._frame()
        x, y = self.screen._to_svg(self._x, self._y)
        lines = txt.split("\n")
        text = SVG.text(
            x=x,
            y=y,
            fill=self.screen._css(color),
            font_family=family,
            font_size=size,
            text_anchor={"center": "middle", "right": "end"}.get(align, "start"),
        )
        words = str(style).lower().split()
        if "bold" in words:
            text.setAttribute("font-weight", "bold")
        if "italic" in words:
            text.setAttribute("font-style", "italic")
        decorations = [
            d
            for w, d in (("underline", "underline"), ("overstrike", "line-through"))
            if w in words
        ]
        if decorations:
            text.setAttribute("text-decoration", " ".join(decorations))
        if any(l != l.strip() or "  " in l for l in lines):
            text.setAttribute("style", "white-space: pre")
        if len(lines) == 1:
            appendTo(text, SVG.Element("inner-text", value=txt))
        else:
            # the text's bottom at the turtle's position
            for i, line in enumerate(lines):
                dy = f"{-1.2 * (len(lines) - 1)}em" if i == 0 else "1.2em"
                appendTo(text, SVG.tspan(line, x=x, dy=dy))
        appendTo(self.screen.canvas, text)
        frame.appear(text)
        self._items.append(text)
        if move:
            width = 0.6 * abs(size) * max(len(l) for l in lines)
            width /= abs(self.screen._xscale)
            end = self._x + {"left": width, "center": width / 2}.get(align, 0)
            self.setpos(end, self._y)

    def begin_poly(self):
        """Start recording the vertices of a polygon."""
        self._poly = [self.pos()]
        self._creatingPoly = True

    def end_poly(self):
        """Stop recording the vertices of a polygon."""
        self._creatingPoly = False

    def get_poly(self):
        """Return the lastly recorded polygon."""
        # check if there is any poly?
        if self._poly is not None:
            return tuple(self._poly)

    def getscreen(self):
        """Return the TurtleScreen object, the turtle is drawing on."""
        return self.screen

    def getturtle(self):
        """Return the Turtle object itself.

        Only reasonable use: as a function to return the 'anonymous turtle'
        """
        return self

    getpen = getturtle

    @_undoable
    def stamp(self):
        """
        Draw a copy of the turtle's shape at its position.

        :return: the stamp's id (for ``clearstamp``).
        """
        frame = self._frame()
        want = self._desired()
        name = want["shape"]
        element = self.screen._shape_element(name)
        transform = f"translate({want['translate']})"
        if self.screen._shapes[name]._type != "image":
            transform += (
                f" rotate({want['rotate']}) skewX({want['skewX']})"
                f" scale({want['scale']})"
            )
        stamp = SVG.g(
            element,
            transform=transform,
            fill=want["fill"],
            stroke=want["stroke"],
            stroke_width=want["stroke-width"],
        )
        appendTo(self.screen.canvas, stamp)
        frame.appear(stamp)
        self._items.append(stamp)
        self.screen._stamp_count += 1
        self._stamps[self.screen._stamp_count] = stamp
        return self.screen._stamp_count

    def clone(self):
        """Create and return a clone of the turtle."""
        q = object.__new__(Turtle)
        q.__dict__.update(
            {
                k: v
                for k, v in vars(self).items()
                if k not in ("_items", "_stamps", "_vis", "_shape_elements")
            }
        )
        for k in ("_fillpath", "_poly"):
            if getattr(q, k) is not None:
                setattr(q, k, list(getattr(q, k)))
        q._undo_depth = 0
        q._attach()
        return q


Pen = Turtle


def done():
    """End the drawing and display it (to call at the end of the program)."""
    Screen().show_scene()


show_scene = done


def replay_scene():
    """Not implemented: print a warning."""
    _warn_not_implemented("turtle.replay_scene")


def restart():
    """Clear the drawing and restore the default configuration."""
    Screen().restart()


# Creating functions based


def getmethparlist(ob):
    """
    Parameter lists of a method (without ``self``), with parentheses: one
    for a definition (with the default values), one for a call.

    :param ob: the method.
    :return: the two lists.
    """
    sig = inspect.signature(ob)
    params = list(sig.parameters.values())[1:]
    call = []
    for p in params:
        if p.kind == p.VAR_POSITIONAL:
            call.append("*" + p.name)
        elif p.kind == p.VAR_KEYWORD:
            call.append("**" + p.name)
        elif p.kind == p.KEYWORD_ONLY:
            call.append(f"{p.name}={p.name}")
        else:
            call.append(p.name)
    return str(sig.replace(parameters=params)), "(%s)" % ", ".join(call)


_tg_screen_functions = [
    "addshape",
    "animation",
    "bgcolor",
    "bgpic",
    "bye",
    "clearscreen",
    "colormode",
    "delay",
    "exitonclick",
    "getcanvas",
    "getshapes",
    "listen",
    "mainloop",
    "mode",
    "numinput",
    "onkey",
    "onkeypress",
    "onkeyrelease",
    "onscreenclick",
    "ontimer",
    "register_shape",
    "resetscreen",
    "save",
    "screensize",
    "setup",
    "setworldcoordinates",
    "svg",
    "textinput",
    "title",
    "tracer",
    "turtles",
    "update",
    "window_height",
    "window_width",
]

_tg_turtle_functions = [
    "back",
    "backward",
    "begin_fill",
    "begin_poly",
    "bk",
    "circle",
    "clear",
    "clearstamp",
    "clearstamps",
    "clone",
    "color",
    "degrees",
    "distance",
    "dot",
    "down",
    "end_fill",
    "end_poly",
    "fd",
    "fillcolor",
    "filling",
    "forward",
    "get_poly",
    "getpen",
    "getscreen",
    "get_shapepoly",
    "getturtle",
    "goto",
    "heading",
    "hideturtle",
    "home",
    "ht",
    "isdown",
    "isvisible",
    "left",
    "lt",
    "onclick",
    "ondrag",
    "onrelease",
    "pd",
    "pen",
    "pencolor",
    "pendown",
    "pensize",
    "penup",
    "pos",
    "position",
    "pu",
    "radians",
    "right",
    "reset",
    "resizemode",
    "rt",
    "seth",
    "setheading",
    "setpos",
    "setposition",
    "settiltangle",
    "setundobuffer",
    "setx",
    "sety",
    "shape",
    "shapesize",
    "shapetransform",
    "shearfactor",
    "showturtle",
    "speed",
    "st",
    "stamp",
    "teleport",
    "tilt",
    "tiltangle",
    "towards",
    "turtlesize",
    "undo",
    "undobufferentries",
    "up",
    "width",
    "write",
    "xcor",
    "ycor",
]


__all__ = (
    _tg_screen_functions
    + _tg_turtle_functions
    + [
        "done",
        "restart",
        "replay_scene",
        "Turtle",
        "Pen",
        "Screen",
        "Shape",
        "Vec2D",
        "Terminator",
        "TurtleGraphicsError",
    ]
)

# The following mechanism makes all methods of RawTurtle and Turtle available
# as functions. So we can enhance, change, add, delete methods to these
# classes and do not need to change anything here.

__func_body = """\
def {name}{paramslist}:
    if {obj} is None:
        {obj} = {init}
    return {obj}.{name}{argslist}
"""


def _make_global_funcs(functions, cls, obj, init):
    """
    Create a module function for each method, called on a default object
    (created on the first call), with the method's docstring.

    :param functions: the methods' names.
    :param cls: their class.
    :param obj: the expression of the default object.
    :param init: the expression creating it.
    """
    for methodname in functions:
        try:
            method = getattr(cls, methodname)
        except AttributeError:
            print("methodname missing:", methodname)
            continue
        pl1, pl2 = getmethparlist(method)
        defstr = __func_body.format(
            obj=obj, init=init, name=methodname, paramslist=pl1, argslist=pl2
        )
        exec(defstr, globals())
        # help(turtle.forward) as help(Turtle.forward)
        globals()[methodname].__doc__ = method.__doc__


_make_global_funcs(_tg_turtle_functions, Turtle, "Turtle._pen", "Turtle()")

_make_global_funcs(_tg_screen_functions, Screen, "Turtle.screen", "Screen()")
