from pyodide import console as _pyodide_console  # type: ignore
from pyodide.console import _CommandCompiler, CodeRunner, _WriteStream  # type: ignore
import js  # type: ignore
from . import kernel, _patch_builtins
import sys
import traceback
import ast
import random
import linecache

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["InteractiveConsole"]

#################################
# pyodide.console monkey-patches
#################################

# force 'exec' mode (forced to 'single' by Pyodide, so monkey-patch!)
# See: https://github.com/pyodide/pyodide/blob/main/src/py/pyodide/console.py#L196
# See: https://docs.python.org/fr/3/library/codeop.html

_call = _CommandCompiler.__call__


def __call(self, source, filename, symbol):
    """
    Compile in ``exec`` mode (Pyodide forces ``single``).

    :param source: the code to compile.
    :param filename: the code's file name.
    :param symbol: the compilation mode, ignored.
    :return: the compiled code, ``None`` if it is incomplete.
    """
    return _call(self, source, filename, "exec")


_CommandCompiler.__call__ = __call


# AST transformers applied to each evaluated code, ala IPython's
# `shell.ast_transformers` (e.g. used by ipytest to rewrite asserts)
ast_transformers = []

# callbacks called (then forgotten) when the kernel stops, to clean up
# what outlives a lazy restart (JS side state like timers or animation
# loops calling back Python code from a cleared namespace)
stop_callbacks = []


def patch_compile_ast_transformers():
    """
    Monkey-patch pyodide.console.CodeRunner to apply `ast_transformers`
    to the ast before compiling.
    """

    def patched_compile(self, *args, **kwargs):
        """
        Apply ``ast_transformers`` then compile.

        :param ``*args``: ``CodeRunner.compile``'s arguments.
        :param ``**kwargs``: ``CodeRunner.compile``'s keyword arguments.
        """
        for transformer in ast_transformers:
            self.ast = ast.fix_missing_locations(transformer.visit(self.ast))
        return _unpatched_compile(self, *args, **kwargs)

    _unpatched_compile = CodeRunner.compile
    CodeRunner.compile = patched_compile


patch_compile_ast_transformers()


def is_call_to(name: str, node: ast.AST):
    """
    Whether a node is the name of a function (e.g. ``input`` in ``input()``).

    :param name: the function's name.
    :param node: the called node.
    """
    return isinstance(node, ast.Name) and node.id == name


def is_attr_of(obj: str, attr: str, node: ast.AST):
    """
    Whether a node is an attribute of a name (e.g. ``time.sleep``).

    :param obj: the name.
    :param attr: the attribute.
    :param node: the called node.
    """
    return (
        isinstance(node, ast.Attribute)
        and node.attr == attr
        and hasattr(node.value, "id")
        and node.value.id == obj
    )


class RewriteAST(ast.NodeTransformer):
    """
    Mutate the given AST tree to automatically transform calls to `input(...)`, `sleep(...)`
    or `time.sleep(...)` that are done at module level in async calls to the related Basthon
    function: `_basthon_input_async` or `_basthon_sleep_async`.

    - Calls inside other functions or in classes or lambda are left untouched.

    - Aliases are ignored. Examples:
        f=input; f()
        import time as T; T.sleep()
    """

    _input_async_name = "_basthon_input_async"
    _sleep_async_name = "_basthon_sleep_async"

    def visit_Call(self, node: ast.Call):
        """
        Turn a call to ``input``, ``sleep`` or ``time.sleep`` into an awaited
        call to its asynchronous version.

        :param node: the call.
        :return: the (possibly awaited) call.
        """
        func = node.func
        set_await = True

        if is_call_to("input", func):  # input(...)
            func.id = self._input_async_name
        elif is_call_to("sleep", func):  # sleep(...)
            func.id = self._sleep_async_name
        elif is_attr_of("time", "sleep", func):  # time.sleep(...)
            node.func = ast.Name(self._sleep_async_name, func.ctx)
        else:  # No modifications
            set_await = False

        if set_await:
            node = ast.Await(node)

        self.generic_visit(node)
        return node

    def _ignore(self, node):
        """
        Do not explore recursively these nodes.

        :param node: a function, lambda or class definition.
        :return: the node, unchanged.
        """
        return node

    visit_FunctionDef = _ignore
    visit_Lambda = _ignore
    visit_ClassDef = _ignore


def patch_compile_input_sleep():
    """
    Monkey-patch pyodide.console.CodeRunner to modify the ast before compiling the commands or
    statements, replacing:
    * calls to `input` with `await _basthon_input_async`
    * calls to `sleep` with `await _basthon_sleep_async`
    * calls to `time.sleep` with `await _basthon_sleep_async`

    This logic is not applied if `js.basthon.syncCommSupport()` is true.

    WARNING: aliases/intermediate variables and calls inside functions or class definitions are
    not handled:

        ```python
        f = input
        s = f("what!?")         # Won't be handled

        import time as T
        T.sleep(1000)           # Won't be handled

        def something():
            s = input(...)      # Won't be modified (same with sleep)

        class Thing:
            s = input(...)      # Won't be modified (same with sleep)
            def method(self):
                s = input(...)  # Won't be modified (same with sleep)
        ```
    """
    if js.basthon.syncCommSupport():
        return

    def patched_compile(self, *args, **kwargs):
        """
        Rewrite ``input`` and ``sleep`` calls (see ``RewriteAST``) then compile.

        :param ``*args``: ``CodeRunner.compile``'s arguments.
        :param ``**kwargs``: ``CodeRunner.compile``'s keyword arguments.
        """
        self.ast = RewriteAST().visit(self.ast)
        return _unpatched_compile(self, *args, **kwargs)

    _unpatched_compile = CodeRunner.compile
    CodeRunner.compile = patched_compile


patch_compile_input_sleep()

# this is absent from Pyodide and is e.g. needed by doctest
_WriteStream.encoding = "utf8"


class _SystemExitWrapper(Exception):
    """Carry a SystemExit through asyncio as an ordinary exception."""

    def __init__(self, system_exit):
        """:param system_exit: the wrapped SystemExit."""
        super().__init__(system_exit)
        self.system_exit = system_exit


class InteractiveConsole(_pyodide_console.PyodideConsole):
    """
    This is the Python's part of Basthon kernel.

    See: https://github.com/pyodide/pyodide/blob/main/src/py/pyodide/console.py#L593
    """

    def __init__(self, *args, **kwargs):
        """
        Create the console, evaluating in ``__main__``'s namespace, with
        persistent redirections of stdout and stderr (to the running
        evaluation's callbacks, or to the JS console between evaluations), and
        start it.

        :param ``*args``: ``PyodideConsole``'s arguments.
        :param ``**kwargs``: ``PyodideConsole``'s keyword arguments.
        """
        self.execution_count = None
        kwargs["globals"] = kwargs.get("globals", sys.modules["__main__"].__dict__)
        kwargs["filename"] = kwargs.get("filename", "<input>")
        kwargs["persistent_stream_redirection"] = True

        # setup persistent streams redirection
        def stdout_callback(text):
            if getattr(self, "_stdout_callback", None) is not None:
                return self._stdout_callback(text)
            else:
                js.console.log(text)

        kwargs["stdout_callback"] = stdout_callback

        def stderr_callback(text):
            if getattr(self, "_stderr_callback", None) is not None:
                return self._stderr_callback(text)
            else:
                js.console.error(text)

        kwargs["stderr_callback"] = stderr_callback

        super().__init__(*args, **kwargs)
        self.locals = self.globals
        self.start()

    # overload to fix filename not taken into account
    def num_frames_to_keep(self, tb):
        """
        Number of frames of a traceback to show: those from the user's code
        (Pyodide's version ignores the console's file name).

        :param tb: the traceback.
        :return: the number of frames kept from the end.
        """
        import traceback

        keep_frames = False
        kept_frames = 0
        # Try to trim out stack frames inside our code
        for frame, _ in traceback.walk_tb(tb):
            keep_frames = keep_frames or frame.f_code.co_filename == self.filename
            keep_frames = keep_frames or frame.f_code.co_filename == "<exec>"
            if keep_frames:
                kept_frames += 1
        return kept_frames

    async def runcode(self, source, code):
        """
        Load the packages imported by the code, await their setups, then run the
        code, wrapping SystemExit (e.g. ``exit()``) into an ordinary exception:
        SystemExit being a BaseException, asyncio reraises it in the event loop
        instead of storing it in the task.

        :param source: the code's source.
        :param code: the compiled code.
        :return: the code's value.
        """
        # packages imported by the code (as PyodideConsole.runcode
        # does, bypassed) then their asynchronous setups
        await js.pyodide.loadPackagesFromImports(source)
        await kernel.setup_packages()
        try:
            return await _pyodide_console.Console.runcode(self, source, code)
        except SystemExit as e:
            raise _SystemExitWrapper(e) from None

    def formattraceback(self, e):
        """
        Format an exception's traceback, a SystemExit wrapped by ``runcode`` as
        an ordinary exception.

        :param e: the exception.
        :return: the formatted traceback.
        """
        if not isinstance(e, _SystemExitWrapper):
            return super().formattraceback(e)
        e = e.system_exit
        nframes = self.num_frames_to_keep(e.__traceback__)
        te = traceback.TracebackException.from_exception(e, limit=-nframes)
        # hide exit/quit internal frame (see _patch_builtins.py)
        if te.stack and te.stack[-1].filename == _patch_builtins.__file__:
            te.stack.pop()
        return "".join(te.format())

    def exit_status(self, e):
        """
        Exit status of a Python program ending with a SystemExit (a message is
        printed on stderr, as Python does).

        :param e: the SystemExit.
        :return: the exit status.
        """
        if e.code is None:
            return 0
        if isinstance(e.code, int):
            return e.code
        print(e.code, file=sys.stderr)
        return 1

    def format_keyboard_interrupt(self, e):
        """
        Format a KeyboardInterrupt's traceback, keeping the user's frames only.

        :param e: the KeyboardInterrupt.
        :return: the formatted traceback.
        """
        frames = [
            frame
            for frame in traceback.extract_tb(e.__traceback__)
            if frame.filename == self.filename
        ]
        return "".join(
            ["Traceback (most recent call last):\n"]
            + traceback.format_list(frames)
            + ["KeyboardInterrupt\n"]
        )

    def banner(self):
        """REPL banner. Taken from PyodideConsole."""
        return _pyodide_console.BANNER

    def roll_in_history(self, code):
        """
        Store an evaluated code in ``In``, as IPython.

        :param code: the code.
        """
        self.locals["In"].append(code)

    def roll_out_history(self, out):
        """
        Store an evaluation's value in ``Out``, ``_``, ``__`` and ``___``, as
        IPython.

        :param out: the value.
        """
        outputs = self.locals["Out"]
        # out is not always stored
        if out is not None and out is not outputs:
            outputs[self.execution_count] = out
            self.locals["___"] = self.locals["__"]
            self.locals["__"] = self.locals["_"]
            self.locals["_"] = out

    def start(self):
        """
        Start the Basthon kernel and fill the namespace.
        """
        self.execution_count = 0
        ast_transformers.clear()
        linecache.clearcache()
        self.locals.clear()
        self.locals.update(
            {
                "__name__": "__main__",
                "__doc__": None,
                "_": "",
                "__": "",
                "___": "",
                "In": [""],
                "Out": {},
            }
        )
        # remember loaded modules at start
        self._modules = set(sys.modules.keys())

    def stop(self):
        """
        Stop the Basthon kernel.
        """
        while stop_callbacks:
            try:
                stop_callbacks.pop()()
            except Exception:
                js.console.error(traceback.format_exc())
        # delete modules imported during session
        excluded = {"setuptools", "numpy"}  # modules that dislike being loaded twice
        for module in set(sys.modules.keys()) - self._modules:
            if module.split(".")[0] not in excluded:
                del sys.modules[module]

    def restart(self):
        """
        Restart the Basthon kernel.
        """
        self.stop()
        self.start()

    def more(self, source):
        """
        Whether the source needs more lines to be evaluated (to choose the
        prompt, ``>>>`` or ``...``).

        :param source: the code typed so far.
        :return: ``True`` if it is incomplete.
        """
        # backup std callbacks to ignore syntax warnings
        stdout_cb = getattr(self, "_stdout_callback", None)
        stderr_cb = getattr(self, "_stderr_callback", None)
        self._stdout_callback = lambda *args, **kwargs: None
        self._stderr_callback = self._stdout_callback

        try:
            code = self._compile(source, self.filename, "exec")
        except (OverflowError, SyntaxError, ValueError):
            return False
        finally:
            # restoring
            if stdout_cb is not None:
                self._stdout_callback = stdout_cb
            if stderr_cb is not None:
                self._stderr_callback = stderr_cb

        if code is None:
            return True

        if "\n" in source:
            return not source.endswith("\n")

        return False

    async def eval(self, code, stdout_callback, stderr_callback, data=None):
        """
        Evaluate Python code, its outputs being sent to the callbacks. ``data``
        is available to the code as ``__eval_data__``. Its optional keys:

        - ``"filename"``: the code's file name (in tracebacks), instead of a
          unique one;
        - ``"exit_on_system_exit"``: a SystemExit (e.g. ``exit()``) is not
          displayed as an exception, the result is then
          ``{"application/x-basthon-exit": status}`` (as the exit status of a
          Python program, e.g. for a command line tool).

        :param code: the code to evaluate.
        :param stdout_callback: called with the text printed on stdout.
        :param stderr_callback: called with the text printed on stderr.
        :param data: the data of the evaluation (a JS object).
        :return: a pair (the MIME bundle of the code's value or ``None``, the
            execution count), or the formatted traceback if the evaluation failed.
        """
        eval_data = data.to_py()
        self.locals["__eval_data__"] = eval_data
        options = eval_data if isinstance(eval_data, dict) else {}
        self.execution_count += 1
        self._stdout_callback = stdout_callback
        self._stderr_callback = stderr_callback
        with kernel.preserve_random_state():
            self.filename = options.get("filename") or (
                f"<basthon-input-{self.execution_count}-{random.randrange(16**12):012x}>"
            )
        linecache.cache[self.filename] = (
            len(code),
            None,
            [line + "\n" for line in code.splitlines()],
            self.filename,
        )

        self.roll_in_history(code)

        fut = self.runsource(code, self.filename)
        try:
            result = await fut
        except KeyboardInterrupt as e:
            # interrupted input (see kernel.interruptible_input)
            return self.format_keyboard_interrupt(e)
        except _SystemExitWrapper as e:
            if not options.get("exit_on_system_exit"):
                return fut.formatted_error
            return {"application/x-basthon-exit": self.exit_status(e.system_exit)}, (
                self.execution_count
            )
        except Exception:
            return fut.formatted_error
        # if fut is incomplete, we should raise an error so recompile
        if fut.syntax_check == "incomplete":
            try:
                self._compile.compiler(code, self.filename, "exec")
            except Exception as e:
                if e.__traceback__:
                    traceback.clear_frames(e.__traceback__)
                return self.formatsyntaxerror(e)
            raise RuntimeError("Internal Basthon error")

        self.roll_out_history(result)
        if result is not None:
            result = kernel.format_repr(result)
        return result, self.execution_count
