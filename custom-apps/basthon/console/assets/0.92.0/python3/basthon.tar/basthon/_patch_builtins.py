from functools import wraps

import js  # type: ignore
import builtins
from . import kernel
from . import importhook

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["patch_all"]


def patch_input():
    """Patching Pyodide input function."""

    @wraps(builtins.input)
    def _patched_input(prompt=None, password=False):
        with kernel.interruptible_input():
            return js.basthon.input(prompt, password)

    # replacing
    builtins.input = _patched_input

    # no need to patch further if sync communication is supported
    if js.basthon.syncCommSupport():
        return

    # define async input (see _console.py: patch_compile_input_sleep & RewriteAST)
    async def input_async(*args, **kwargs):
        local_input = kernel.locals().get("input", builtins.input)
        if local_input != _patched_input:
            return local_input(*args, **kwargs)
        return await kernel.input_async(*args, **kwargs)

    builtins._basthon_input_async = input_async


def patch_getpass():
    """
    Patching getpass.getpass to use a password input
    (the default one falls back to an echoed input).

    It is not a builtin function but it relies on input.
    The patch is applied when getpass is imported (not to slow down
    the kernel's start).
    """

    @importhook.on_import("getpass")
    def _patch(getpass):
        @wraps(getpass.getpass)
        def _patched_getpass(prompt="Password: ", stream=None):
            return builtins.input(prompt, password=True)

        getpass.getpass = _patched_getpass


class _Quitter(type(builtins.exit)):
    """exit/quit without closing sys.stdin (it would break input, help, ...)."""

    def __call__(self, code=None):
        """
        Exit the program (raise SystemExit).

        :param code: the exit status or message.
        """
        raise SystemExit(code)


def patch_exit():
    """Patching exit and quit builtins."""
    for name in ("exit", "quit"):
        quitter = getattr(builtins, name)
        setattr(builtins, name, _Quitter(quitter.name, quitter.eof))


def patch_sleep():
    """
    Patching time.sleep function for toplevel async calls.

    It is not a builtin function but the patch put stuff in builtins.
    """
    # no need to patch if sync communication is supported
    if js.basthon.syncCommSupport():
        return

    # define async sleep (see _console.py: patch_compile_input_sleep & RewriteAST)
    async def sleep_async(*args, **kwargs):
        import time

        local_sleep = kernel.locals().get("sleep", time.sleep)
        if local_sleep != time.sleep:
            return local_sleep(*args, **kwargs)
        return await kernel.sleep_async(*args, **kwargs)

    builtins._basthon_sleep_async = sleep_async


def patch_all():
    """
    Patch all builtins by calling all patch_* methods.
    """
    for name, method in globals().items():
        if name.startswith("patch_") and name != "patch_all":
            method()
