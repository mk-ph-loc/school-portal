"""
Hooks called when a module is imported.

.. code:: python

    from . import importhook

    @importhook.on_import("socket")
    def patch_socket(socket):
        ...

A hook is called with the module once it is executed (at once if it is
already imported). The hooks of a module run in their registration order
and a hook returning a module replaces it in sys.modules. An exception in
a hook is reported on the console: the import goes on without this hook.

Only the hooked modules are concerned: a finder (first of sys.meta_path)
asks the next finders for their spec and wraps its loader.
"""

import sys
import traceback

import js  # type: ignore

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["on_import"]


# module name -> hooks
_hooks = {}


def _run_hook(name, hook):
    try:
        module = hook(sys.modules[name])
    except Exception:
        js.console.error(traceback.format_exc())
        return
    if module is not None:
        sys.modules[name] = module


class _HookLoader:
    """
    Wrapper of a module's loader that runs the module's hooks once it is
    executed.
    """

    def __init__(self, loader):
        self.loader = loader

    def __getattr__(self, name):
        return getattr(self.loader, name)

    def exec_module(self, module):
        self.loader.exec_module(module)
        # the module keeps its own loader
        if module.__loader__ is self:
            module.__loader__ = self.loader
        if module.__spec__.loader is self:
            module.__spec__.loader = self.loader
        # a module can replace itself in sys.modules while executing
        # (e.g. py through apipkg, needed by pytest): the hooks get the
        # replacement
        name = module.__spec__.name
        for hook in _hooks[name]:
            _run_hook(name, hook)


class _HookFinder:
    """
    Finder of the hooked modules: the spec of the next finders, with
    a loader running the hooks.
    """

    @staticmethod
    def find_spec(fullname, path, target=None):
        if fullname not in _hooks or _HookFinder not in sys.meta_path:
            return None
        index = sys.meta_path.index(_HookFinder)
        for finder in sys.meta_path[index + 1 :]:
            find_spec = getattr(finder, "find_spec", None)
            if find_spec is None:
                continue
            spec = find_spec(fullname, path, target)
            if spec is None:
                continue
            if hasattr(spec.loader, "exec_module"):
                spec.loader = _HookLoader(spec.loader)
            return spec
        return None


sys.meta_path.insert(0, _HookFinder)


def on_import(module_name, hook=None):
    """
    Register a hook called with the module `module_name` once it is
    imported (at once if it is already imported). Usable as a decorator.
    """
    if hook is None:

        def decorator(hook):
            on_import(module_name, hook)
            return hook

        return decorator
    _hooks.setdefault(module_name, []).append(hook)
    if module_name in sys.modules:
        _run_hook(module_name, hook)
