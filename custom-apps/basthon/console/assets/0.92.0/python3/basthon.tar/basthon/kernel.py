"""
This is the Python part of the Basthon Kernel.
"""

try:
    import js  # type: ignore
    from pyodide.ffi import to_js, JsProxy, JsException  # type: ignore

    inside_pyodide = True
except ImportError:
    # we are probably importing this outside of Pyodide (e.g. a tool)
    inside_pyodide = False

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"

from typing import Union, Optional, Any
from contextlib import contextmanager

if inside_pyodide:
    import os
    import sys
    import asyncio
    from ._console import InteractiveConsole
    from . import _patch_modules

    # where we put user supplied modules
    _user_modules_root = "/basthon_user_modules"
    # we don't insert at position 0 since
    # https://github.com/iodide-project/pyodide/issues/737#issuecomment-750858417
    sys.path.insert(2, _user_modules_root)

    # interpretation system is the Pyodide's interactive console
    _console = InteractiveConsole()

    # copying methods from _console to this module
    for f in ("eval", "complete", "banner", "more"):
        globals()[f] = getattr(_console, f)


def locals():
    """Global namespace of the evaluations (the user's variables)."""
    return _console.locals


def display_event(data):
    """
    Dispatch an ``eval.display`` event.

    :param data: the event's data, e.g. a MIME bundle (a dict mapping MIME
        types to the content).
    """
    js.basthon.display(to_js(data, dict_converter=js.Object.fromEntries))


@contextmanager
def interruptible_input():
    """
    Turn an interrupted input (e.g. the user ran a script again while
    the program was waiting for an answer) or sleep into a
    KeyboardInterrupt, and the end of the input (e.g. a closed stdin)
    into an EOFError.
    """
    try:
        yield
    except JsException as e:
        if getattr(e, "name", None) == "InputEOFError":
            raise EOFError("EOF when reading a line") from None
        if getattr(e, "name", None) != "InputInterruptedError":
            raise
        handle_keyboard_interrupts()
        raise KeyboardInterrupt from None


def handle_keyboard_interrupts():
    """
    Let the evaluations report the KeyboardInterrupts (e.g. an interrupted
    input or code interrupted by Pyodide's interrupt buffer): Pyodide's
    event loop re-raises a KeyboardInterrupt escaping a task (printing a
    second traceback) unless it has a handler.
    """
    loop = asyncio.get_event_loop()
    if getattr(loop, "_keyboard_interrupt_handler", False) is None:
        loop._keyboard_interrupt_handler = lambda: None


async def input_async(prompt=None, password=False):
    """
    Wait for the user's input through an ``eval.input`` event, when the kernel
    has no synchronous communication (the code's ``input`` calls are turned
    into ``await input_async(...)``, see ``_console.RewriteAST``).

    :param prompt: the text shown before the input.
    :param password: whether the typed text is hidden.
    :return: the typed text.
    """
    if js.basthon.syncCommSupport():
        raise RuntimeError(
            "Trying to use legacy input inside kernel that supports sync communication."
        )
    eval_data = _console.locals["__eval_data__"]
    eval_data = to_js(eval_data, dict_converter=js.Object.fromEntries)
    with interruptible_input():
        return await js.basthon.toplevelInput(prompt, password, eval_data)


async def sleep_async(secs):
    """
    Suspend the execution (asynchronous ``time.sleep``, used without
    synchronous communication).

    :param secs: the number of seconds to wait.
    """
    await asyncio.sleep(secs)


def clear_output(wait=True):
    """
    Clear the output of the running notebook cell, as IPython's
    ``clear_output`` (useful for animations). The console ignores it.

    :param wait: if ``True``, the output is cleared only when new output
                 is displayed, which avoids flickering.
    """
    js.basthon.clearOutput(wait)


def format_repr(obj):
    """
    MIME bundle of an object: its ``repr`` as ``text/plain``, and the results
    of its ``_repr_html_``, ``_repr_svg_``, ``_repr_png_``, ``_repr_latex_``
    and ``_repr_markdown_`` methods if it has some (as IPython). A method
    raising an error or returning ``None`` is ignored.

    :param obj: the object.
    :return: a dict mapping MIME types to the representations.
    """
    res = {"text/plain": repr(obj)}
    mimes = {
        "text/html": "_repr_html_",
        "image/svg+xml": "_repr_svg_",
        "image/png": "_repr_png_",
        "text/latex": "_repr_latex_",
        "text/markdown": "_repr_markdown_",
    }
    for mime, _repr in mimes.items():
        if hasattr(obj, _repr):
            try:
                representation = getattr(obj, _repr)()
                if representation is not None:
                    res[mime] = representation
            except Exception:
                pass
    return res


def display(
    *objs: Any,
    include: Union[None, list, tuple, set] = None,
    exclude: Union[None, list, tuple, set] = None,
    metadata: Optional[dict] = None,
    transient: Optional[dict] = None,
    display_id: Union[None, str, bool] = None,
    raw: Optional[bool] = False,
    clear: Optional[bool] = False,
    **kwargs,
):
    """
    Display Python objects in the console's graphical output or under the
    notebook's cell, with their richest representation (HTML, SVG, PNG,
    LaTeX or Markdown, see the ``_repr_*_`` methods of IPython).

    :param ``*objs``: the objects to display.
    :param raw: if ``True``, the objects are already MIME bundles (dicts
        mapping MIME types to the content), displayed as they are.
    :param include: ignored (compatibility with IPython's ``display``).
    :param exclude: ignored (compatibility with IPython's ``display``).
    :param metadata: ignored (compatibility with IPython's ``display``).
    :param transient: ignored (compatibility with IPython's ``display``).
    :param display_id: ignored (compatibility with IPython's ``display``).
    :param clear: ignored (compatibility with IPython's ``display``).
    :param ``**kwargs``: ignored (compatibility with IPython's ``display``).
    """
    for obj in objs:
        if not raw:
            obj = format_repr(obj)
        display_event(obj)


def download(filename: str, data: Optional[Union[str, bytes]] = None):
    """
    Download a file of the virtual filesystem, or data, to the user's
    computer (the browser saves it as a downloaded file).

    Usage:

    >>> download("path/to/file")
    >>> download("filename", data)

    :param filename: the path of the file to download if ``data`` is
        ``None``, otherwise the name of the downloaded file.
    :param data: the data to download (text is encoded in UTF-8), or
        ``None`` to download the file ``filename``.
    """
    if data is None:
        data = get_file(filename)
        _, filename = os.path.split(filename)
    if isinstance(data, str):
        data = data.encode()
    js.basthon.download(to_js(data), filename)


def put_file(filepath, content):
    """
    Write a file in the virtual filesystem (creating its directory).

    :param filepath: the file's path.
    :param content: the file's content (bytes or a JS buffer).
    """
    if isinstance(content, JsProxy):
        content = content.to_py()
    dirname, _ = os.path.split(filepath)
    if dirname:
        os.makedirs(dirname, exist_ok=True)

    with open(filepath, "wb") as f:
        f.write(content)


# number of loaded packages when setup_packages last looked for setups
# (the kernel's packages have none)
_loaded_packages_count = (
    js.Object.keys(js.pyodide.loadedPackages).length if inside_pyodide else 0
)
# names of the setups already awaited
_setups_done = set()


async def setup_packages():
    """
    Await the setups of the newly loaded packages, declared as entry points
    of the "basthon.setup" group (coroutine functions): what can't be done
    synchronously at import (e.g. instantiating a Wasm module of a JS part).
    To be called once the packages are loaded, before running the code
    importing them.
    """
    global _loaded_packages_count
    count = js.Object.keys(js.pyodide.loadedPackages).length
    if count == _loaded_packages_count:
        return
    _loaded_packages_count = count

    from importlib.metadata import entry_points

    for entry_point in entry_points(group="basthon.setup"):
        if entry_point.name not in _setups_done:
            _setups_done.add(entry_point.name)
            await entry_point.load()()


async def put_module(filename, content):
    """
    Install a user's module (a ``*.py`` file) in the user's modules directory,
    after loading the packages it imports. A module whose name starts with
    ``_`` is compiled to ``.pyc`` (its source is not kept).

    :param filename: the module's file name.
    :param content: the module's source (bytes or a JS buffer).
    """
    if isinstance(content, JsProxy):
        content = content.to_py()
    source = content.tobytes().decode()
    await js.pyodide.loadPackagesFromImports(source)
    await setup_packages()

    _, fname = os.path.split(filename)
    module_path = os.path.join(_user_modules_root, fname)
    put_file(module_path, content)
    # modules with '_' prefix are compiled to pyc
    if filename.startswith("_"):
        import py_compile

        py_compile.compile(module_path, cfile=f"{module_path}c")
        os.unlink(module_path)
    # the user's module root may have been looked up before it existed
    # (cached as None): the finder of this directory only is reset since
    # importlib.invalidate_caches is slow (it reads the stdlib's zip again)
    sys.path_importer_cache.pop(_user_modules_root, None)


def user_modules():
    """
    List the user's modules installed by ``put_module``.

    :return: their file names.
    """
    if not os.path.exists(_user_modules_root):
        return []
    return [
        f
        for f in os.listdir(_user_modules_root)
        if f.endswith(".py") or f.endswith(".pyc")
    ]


def get_file(filepath):
    """
    Read a file of the virtual filesystem.

    :param filepath: the file's path.
    :return: the file's content (bytes).
    """
    with open(filepath, "rb") as fd:
        return fd.read()


def get_user_module_file(filename):
    """
    Read a user's module installed by ``put_module``.

    :param filename: the module's file name.
    :return: the module's content (bytes).
    """
    return get_file(os.path.join(_user_modules_root, filename))


def list_basthon_modules(pure_basthon=False):
    """
    List the packages available in Pyodide's lockfile (Pyodide's and
    Basthon's).

    :param pure_basthon: if ``True``, only the packages added by Basthon
        (their distribution names), otherwise the import names of all the
        packages.
    :return: the names of the packages.
    """
    if pure_basthon:
        packages = js.pyodide._api.lockfile_packages.to_py()
        root_url = js.basthon.basthonModulesRoot()
        packages = [
            p["name"] for p in packages.values() if p["file_name"].startswith(root_url)
        ]
    else:
        packages = js.pyodide._api._import_name_to_package_name.to_py()
        packages = [p for p in packages.keys() if "." not in p] + ["js"]
    return packages


def importables():
    """
    List all the importable modules (e.g. for tests and documentation).

    :return: the sorted names of the modules.
    """
    import pkgutil

    from_sys = set(x for x in sys.modules.keys() if "." not in x)
    from_pkgutil = set(p.name for p in pkgutil.iter_modules())
    from_basthon = set(list_basthon_modules())
    return sorted(from_sys.union(from_pkgutil, from_basthon))


def start():
    """Start the kernel: empty namespace, history and execution count reset."""
    return _console.start()


def stop():
    """
    Stop the kernel: call the ``on_stop`` callbacks and forget the modules
    imported since the start.
    """
    return _console.stop()


def restart():
    """Restart the kernel (``stop`` then ``start``)."""
    return _console.restart()


def on_stop(callback):
    """
    Register a callback called once when the kernel stops (e.g. on restart).

    :param callback: a function without argument.
    """
    from ._console import stop_callbacks

    stop_callbacks.append(callback)


def execution_count():
    """
    Number of the last evaluation since the start.

    :return: the execution count.
    """
    return _console.execution_count


@contextmanager
def preserve_random_state():
    """
    Context manager keeping the state of the random generator unchanged: the
    kernel's own draws (e.g. a file name) don't change the user's seeded
    sequence.
    """
    import random

    state = random.getstate()
    random.seed()
    try:
        yield
    finally:
        random.setstate(state)
